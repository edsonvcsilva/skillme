"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Send, Paperclip, MoreVertical, Phone, Video } from "lucide-react"
import { MainLayout } from "@/components/layout/main-layout"
import { useAuth } from "@/lib/auth-context"
import { users, getMessagesBetweenUsers, getUnreadMessageCountFromSender } from "@/lib/data"

export default function MessagesPage() {
  const { user: currentUser } = useAuth()
  const [selectedUser, setSelectedUser] = useState(users[0])
  const [newMessage, setNewMessage] = useState("")

  if (!currentUser) return null

  // Filter out the current user from the contacts list
  const contacts = users.filter((u) => u.id !== currentUser.id)

  // Get messages between current user and selected user
  const messages = getMessagesBetweenUsers(currentUser.id, selectedUser.id)

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (newMessage.trim()) {
      // In a real app, this would send the message to the server
      // For now, we'll just clear the input
      setNewMessage("")
    }
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="border rounded-lg overflow-hidden grid grid-cols-1 md:grid-cols-[300px_1fr] h-[calc(100vh-200px)]">
          {/* Contacts sidebar */}
          <div className="border-r">
            <div className="p-4 border-b">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search messages..." className="pl-8" />
              </div>
            </div>
            <div className="overflow-auto h-[calc(100vh-280px)]">
              {contacts.map((contact) => {
                const unreadCount = getUnreadMessageCountFromSender(currentUser.id, contact.id)
                const lastMessage = getMessagesBetweenUsers(currentUser.id, contact.id).slice(-1)[0]

                return (
                  <div
                    key={contact.id}
                    className={`p-4 flex items-start gap-3 hover:bg-muted/50 cursor-pointer ${
                      selectedUser.id === contact.id ? "bg-muted" : ""
                    }`}
                    onClick={() => setSelectedUser(contact)}
                  >
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>
                          {contact.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      {contact.isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-background rounded-full"></span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-sm">{contact.name}</h3>
                        <span className="text-xs text-muted-foreground">
                          {lastMessage
                            ? new Date(lastMessage.createdAt).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })
                            : ""}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-muted-foreground truncate">
                          {lastMessage ? lastMessage.content : "No messages yet"}
                        </p>
                        {unreadCount > 0 && (
                          <span className="bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
                            {unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Chat area */}
          <div className="flex flex-col">
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={selectedUser.avatar || "/placeholder.svg"} alt={selectedUser.name} />
                  <AvatarFallback>
                    {selectedUser.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="font-medium">{selectedUser.name}</h2>
                  <p className="text-xs text-muted-foreground">{selectedUser.isOnline ? "Online" : "Offline"}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon">
                  <Phone className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Video className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-4 flex flex-col gap-4 h-[calc(100vh-340px)]">
              {messages.map((message) => {
                const isFromCurrentUser = message.senderId === currentUser.id
                const sender = isFromCurrentUser ? currentUser : selectedUser

                return (
                  <div
                    key={message.id}
                    className={`flex items-start gap-3 max-w-[80%] ${
                      isFromCurrentUser ? "self-end flex-row-reverse" : ""
                    }`}
                  >
                    <Avatar>
                      <AvatarImage src={sender.avatar || "/placeholder.svg"} alt={sender.name} />
                      <AvatarFallback>
                        {sender.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`${
                        isFromCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                      } rounded-lg p-3`}
                    >
                      <p className="text-sm">{message.content}</p>
                      <span
                        className={`text-xs ${
                          isFromCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground"
                        } mt-1 block`}
                      >
                        {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                )
              })}

              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                  <p>No messages yet</p>
                  <p className="text-sm">Send a message to start the conversation</p>
                </div>
              )}
            </div>

            <div className="p-4 border-t">
              <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                <Button variant="ghost" size="icon" type="button">
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Type a message..."
                  className="flex-1"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                />
                <Button size="icon" type="submit" disabled={!newMessage.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
