"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { ServiceCard } from "@/components/service-card"
import { Search, SlidersHorizontal } from "lucide-react"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { MainLayout } from "@/components/layout/main-layout"
import { services, users } from "@/lib/data"
import { useState } from "react"

export default function ServicesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [minRating, setMinRating] = useState(0)

  // Filter services based on search criteria
  const filteredServices = services.filter((service) => {
    const matchesSearch =
      searchTerm === "" ||
      service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = selectedCategory === "all" || service.category === selectedCategory

    const matchesRating = service.rating >= minRating

    return matchesSearch && matchesCategory && matchesRating
  })

  // Get unique categories from services
  const categories = ["all", ...Array.from(new Set(services.map((service) => service.category)))]

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <h1 className="text-3xl font-bold text-[#073761]">Services</h1>
          <div className="flex w-full md:w-auto gap-2">
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search services..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <SlidersHorizontal className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>Refine your search results</SheetDescription>
                </SheetHeader>
                <div className="grid gap-6 py-4">
                  <div className="grid gap-2">
                    <Label>Category</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category === "all" ? "All Categories" : category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label>Rating</Label>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Minimum Rating</span>
                      <span className="text-sm font-medium">{minRating.toFixed(1)}</span>
                    </div>
                    <Slider
                      defaultValue={[0]}
                      max={5}
                      step={0.1}
                      value={[minRating]}
                      onValueChange={(value) => setMinRating(value[0])}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Skills</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {["JavaScript", "React", "Node.js", "UI/UX", "Python", "Marketing", "SEO", "Content"].map(
                        (skill) => (
                          <div key={skill} className="flex items-center space-x-2">
                            <Checkbox id={`skill-${skill}`} />
                            <label
                              htmlFor={`skill-${skill}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {skill}
                            </label>
                          </div>
                        ),
                      )}
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label>Location</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Any Location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any Location</SelectItem>
                        <SelectItem value="remote">Remote Only</SelectItem>
                        <SelectItem value="local">Local Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="bg-[#055294] hover:bg-[#073761]">Apply Filters</Button>
                </div>
              </SheetContent>
            </Sheet>
            <Select>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by: Relevance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="rating">Highest Rating</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="oldest">Oldest</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.length > 0 ? (
            filteredServices.map((service) => {
              const serviceProvider = users.find((u) => u.id === service.userId)!
              return (
                <ServiceCard
                  key={service.id}
                  id={service.id}
                  title={service.title}
                  description={service.description}
                  rating={service.rating}
                  reviewCount={service.reviewCount}
                  category={service.category}
                  userName={serviceProvider.name}
                  userAvatar={serviceProvider.avatar}
                  image={service.image}
                />
              )
            })
          ) : (
            <div className="col-span-3 py-12 text-center">
              <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-[#055294]" />
              </div>
              <h3 className="text-lg font-medium mb-2">No services found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCategory("all")
                  setMinRating(0)
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>

        {filteredServices.length > 0 && (
          <div className="flex justify-center mt-8">
            <Button variant="outline" className="mx-auto">
              Load More
            </Button>
          </div>
        )}
      </div>
    </MainLayout>
  )
}
