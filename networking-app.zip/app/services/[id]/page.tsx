"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, MessageSquare, Calendar, Share2, Bookmark, Flag, UserPlus, UserCheck } from "lucide-react"
import { MainLayout } from "@/components/layout/main-layout"
import { getServiceById, getUserById, users } from "@/lib/data"
import { useParams, useRouter } from "next/navigation"
import { notFound } from "next/navigation"
import Link from "next/link"
import { useConnection } from "@/lib/connection-context"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/hooks/use-toast"

export default function ServiceDetailPage() {
  const params = useParams()
  const serviceId = params.id as string
  const { user: currentUser } = useAuth()
  const { getConnectionStatus, sendConnectionRequest } = useConnection()
  const router = useRouter()
  const { toast } = useToast()

  const service = getServiceById(serviceId)

  if (!service) {
    notFound()
  }

  const serviceProvider = getUserById(service.userId)!

  // Don't show connection button for current user
  const isCurrentUser = currentUser?.id === serviceProvider.id
  const connectionStatus = getConnectionStatus(serviceProvider.id)

  const handleConnect = () => {
    if (connectionStatus === "none") {
      sendConnectionRequest(serviceProvider.id)
      toast({
        title: "Connection Request Sent",
        description: `You sent a connection request to ${serviceProvider.name}`,
      })
    } else if (connectionStatus === "accepted") {
      router.push(`/messages?userId=${serviceProvider.id}`)
    }
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-2 text-[#073761]">{service.title}</h1>
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <Badge>{service.category}</Badge>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                  <span className="font-medium">{service.rating}</span>
                  <span className="text-muted-foreground">({service.reviewCount} reviews)</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  Created on {new Date(service.createdAt).toLocaleDateString()}
                </span>
              </div>
              <div className="rounded-lg overflow-hidden mb-6 bg-muted h-[300px] md:h-[400px]">
                <img
                  src={service.image || "/placeholder.svg"}
                  alt={service.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback if image fails to load
                    ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=400&width=800"
                  }}
                />
              </div>
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-[#073761]">Description</h2>
                <p>{service.description}</p>
              </div>
            </div>

            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-[#073761]">Reviews</h2>
                <Button variant="outline">Write a Review</Button>
              </div>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => {
                  const reviewer = users[i % users.length]
                  return (
                    <Card key={i} className="border-[#2580B7]/20">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <Avatar>
                            <AvatarImage src={reviewer.avatar || "/placeholder.svg"} alt={reviewer.name} />
                            <AvatarFallback>
                              {reviewer.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <div>
                                <h3 className="font-medium">{reviewer.name}</h3>
                              </div>
                              <div className="flex items-center gap-1">
                                {Array(5)
                                  .fill(0)
                                  .map((_, index) => (
                                    <Star
                                      key={index}
                                      className={`h-4 w-4 ${index < 5 ? "fill-[#055294] text-[#055294]" : "text-muted"}`}
                                    />
                                  ))}
                              </div>
                            </div>
                            <p className="text-sm">
                              {serviceProvider.name} did an excellent job. Very professional, responsive, and delivered
                              high-quality work. I would definitely recommend this service.
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">March {15 - i}, 2025</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          </div>

          <div>
            <Card className="sticky top-24 border-[#2580B7]/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-6">
                  <Avatar className="h-14 w-14">
                    <AvatarImage src={serviceProvider.avatar || "/placeholder.svg"} alt={serviceProvider.name} />
                    <AvatarFallback>
                      {serviceProvider.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <Link href={`/profile/${serviceProvider.id}`} className="font-medium text-lg hover:text-[#055294]">
                      {serviceProvider.name}
                    </Link>
                    <p className="text-sm text-muted-foreground">{serviceProvider.title}</p>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span className="text-sm">Response Rate</span>
                    <span className="text-sm font-medium">98%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Response Time</span>
                    <span className="text-sm font-medium">~2 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Member Since</span>
                    <span className="text-sm font-medium">
                      {new Date(serviceProvider.memberSince).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                      })}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  {!isCurrentUser &&
                    (connectionStatus === "none" ? (
                      <Button className="w-full gap-2 bg-[#055294] hover:bg-[#073761]" onClick={handleConnect}>
                        <UserPlus className="h-4 w-4" />
                        Connect with Provider
                      </Button>
                    ) : connectionStatus === "pending" ? (
                      <Button variant="outline" className="w-full gap-2" disabled>
                        <UserCheck className="h-4 w-4" />
                        Request Sent
                      </Button>
                    ) : connectionStatus === "received" ? (
                      <Button
                        className="w-full gap-2 bg-[#055294] hover:bg-[#073761]"
                        onClick={() => router.push("/connections")}
                      >
                        <UserCheck className="h-4 w-4" />
                        Respond to Request
                      </Button>
                    ) : (
                      <Button
                        className="w-full gap-2 bg-[#055294] hover:bg-[#073761]"
                        onClick={() => router.push(`/messages?userId=${serviceProvider.id}`)}
                      >
                        <MessageSquare className="h-4 w-4" />
                        Message Provider
                      </Button>
                    ))}

                  <Button
                    variant={isCurrentUser ? "default" : "outline"}
                    className={`w-full gap-2 ${isCurrentUser ? "bg-[#055294] hover:bg-[#073761]" : ""}`}
                  >
                    <Link href={`/profile/${serviceProvider.id}`} className="flex items-center gap-2 w-full">
                      View Full Profile
                    </Link>
                  </Button>

                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1 gap-2">
                      <Share2 className="h-4 w-4" />
                      Share
                    </Button>
                    <Button variant="outline" className="flex-1 gap-2">
                      <Bookmark className="h-4 w-4" />
                      Save
                    </Button>
                  </div>
                  <Button variant="ghost" size="sm" className="w-full text-muted-foreground gap-2">
                    <Flag className="h-4 w-4" />
                    Report Service
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
