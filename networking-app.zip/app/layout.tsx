import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/lib/auth-context"
import { ConnectionProvider } from "@/lib/connection-context"
import { WalletProvider } from "@/lib/wallet-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ConnectPro - Professional Networking",
  description: "Connect with professionals, exchange services, and build your reputation",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <ConnectionProvider>
            <WalletProvider>{children}</WalletProvider>
          </ConnectionProvider>
        </AuthProvider>
      </body>
    </html>
  )
}


import './globals.css'