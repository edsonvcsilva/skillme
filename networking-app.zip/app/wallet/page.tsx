"use client"

import { useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useWallet } from "@/lib/wallet-context"
import { useAuth } from "@/lib/auth-context"
import {
  Wallet,
  CreditCard,
  ArrowUpRight,
  ArrowDownLeft,
  Gift,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function WalletPage() {
  const { user } = useAuth()
  const { wallet, addFunds, withdrawFunds, getRecentTransactions, isLoading } = useWallet()
  const [amount, setAmount] = useState("")
  const [isAddingFunds, setIsAddingFunds] = useState(false)
  const [isWithdrawing, setIsWithdrawing] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("credit_card")

  if (!user || isLoading) {
    return (
      <MainLayout>
        <div className="container py-8 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </MainLayout>
    )
  }

  const transactions = getRecentTransactions()

  const handleAddFunds = async () => {
    const amountValue = Number.parseFloat(amount)
    if (isNaN(amountValue) || amountValue <= 0) return

    setIsAddingFunds(true)
    try {
      await addFunds(amountValue)
      setAmount("")
    } finally {
      setIsAddingFunds(false)
    }
  }

  const handleWithdraw = async () => {
    const amountValue = Number.parseFloat(amount)
    if (isNaN(amountValue) || amountValue <= 0 || (wallet && amountValue > wallet.balance)) return

    setIsWithdrawing(true)
    try {
      await withdrawFunds(amountValue)
      setAmount("")
    } finally {
      setIsWithdrawing(false)
    }
  }

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowUpRight className="h-4 w-4 text-green-500" />
      case "withdrawal":
        return <ArrowDownLeft className="h-4 w-4 text-red-500" />
      case "payment":
        return <CreditCard className="h-4 w-4 text-red-500" />
      case "refund":
        return <ArrowUpRight className="h-4 w-4 text-green-500" />
      case "points_earned":
        return <Gift className="h-4 w-4 text-[#055294]" />
      case "points_used":
        return <Gift className="h-4 w-4 text-orange-500" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-amber-500" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const formatAmount = (type: string, amount: number) => {
    if (type === "points_earned" || type === "points_used") {
      return `${amount > 0 ? "+" : ""}${amount} points`
    }
    return `${amount > 0 ? "+" : ""}$${Math.abs(amount).toFixed(2)}`
  }

  const getAmountColor = (type: string, amount: number) => {
    if (type === "points_earned") return "text-[#055294]"
    if (type === "points_used") return "text-orange-500"
    return amount > 0 ? "text-green-500" : "text-red-500"
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <h1 className="text-3xl font-bold text-[#073761]">Digital Wallet</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card className="border-[#2580B7]/20">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Wallet className="h-5 w-5 text-[#055294]" />
                    Balance
                  </CardTitle>
                  <CardDescription>Your current wallet balance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">${wallet?.balance.toFixed(2) || "0.00"}</div>
                  <div className="flex gap-2 mt-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="flex-1 bg-[#055294] hover:bg-[#073761]">Add Funds</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Funds to Wallet</DialogTitle>
                          <DialogDescription>
                            Enter the amount you want to add to your wallet balance.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="amount">Amount</Label>
                            <Input
                              id="amount"
                              type="number"
                              placeholder="0.00"
                              value={amount}
                              onChange={(e) => setAmount(e.target.value)}
                              min="0"
                              step="0.01"
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="payment-method">Payment Method</Label>
                            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                              <SelectTrigger id="payment-method">
                                <SelectValue placeholder="Select payment method" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="credit_card">Credit Card</SelectItem>
                                <SelectItem value="debit_card">Debit Card</SelectItem>
                                <SelectItem value="paypal">PayPal</SelectItem>
                                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            onClick={handleAddFunds}
                            disabled={isAddingFunds || !amount || Number.parseFloat(amount) <= 0}
                            className="bg-[#055294] hover:bg-[#073761]"
                          >
                            {isAddingFunds ? "Processing..." : "Add Funds"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="flex-1">
                          Withdraw
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Withdraw Funds</DialogTitle>
                          <DialogDescription>Enter the amount you want to withdraw from your wallet.</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="withdraw-amount">Amount</Label>
                            <Input
                              id="withdraw-amount"
                              type="number"
                              placeholder="0.00"
                              value={amount}
                              onChange={(e) => setAmount(e.target.value)}
                              min="0"
                              max={wallet?.balance || 0}
                              step="0.01"
                            />
                            <p className="text-xs text-muted-foreground">
                              Available balance: ${wallet?.balance.toFixed(2) || "0.00"}
                            </p>
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="withdraw-method">Withdrawal Method</Label>
                            <Select defaultValue="bank_account">
                              <SelectTrigger id="withdraw-method">
                                <SelectValue placeholder="Select withdrawal method" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="bank_account">Bank Account</SelectItem>
                                <SelectItem value="paypal">PayPal</SelectItem>
                                <SelectItem value="venmo">Venmo</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            onClick={handleWithdraw}
                            disabled={
                              isWithdrawing ||
                              !amount ||
                              Number.parseFloat(amount) <= 0 ||
                              (wallet && Number.parseFloat(amount) > wallet.balance)
                            }
                            className="bg-[#055294] hover:bg-[#073761]"
                          >
                            {isWithdrawing ? "Processing..." : "Withdraw Funds"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-[#2580B7]/20">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Gift className="h-5 w-5 text-[#055294]" />
                    Reward Points
                  </CardTitle>
                  <CardDescription>Points earned from transactions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{wallet?.points || 0} points</div>
                  <div className="flex gap-2 mt-4">
                    <Button className="flex-1 bg-[#055294] hover:bg-[#073761]">Redeem Points</Button>
                    <Button variant="outline" className="flex-1">
                      How to Earn
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-[#2580B7]/20">
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>Recent activity in your wallet</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all">
                  <TabsList className="grid w-full grid-cols-4 mb-6">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="money">Money</TabsTrigger>
                    <TabsTrigger value="points">Points</TabsTrigger>
                    <TabsTrigger value="payments">Payments</TabsTrigger>
                  </TabsList>

                  <TabsContent value="all">
                    {transactions.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground">No transactions yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {transactions.map((transaction) => (
                          <div
                            key={transaction.id}
                            className="flex items-center justify-between py-3 border-b last:border-0"
                          >
                            <div className="flex items-start gap-3">
                              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                {getTransactionIcon(transaction.type)}
                              </div>
                              <div>
                                <p className="font-medium">{transaction.description}</p>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  <span>{new Date(transaction.date).toLocaleString()}</span>
                                  <div className="flex items-center gap-1">
                                    {getStatusIcon(transaction.status)}
                                    <span className="capitalize">{transaction.status}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className={`font-medium ${getAmountColor(transaction.type, transaction.amount)}`}>
                              {formatAmount(transaction.type, transaction.amount)}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="money">
                    {transactions.filter((t) => t.type === "deposit" || t.type === "withdrawal" || t.type === "refund")
                      .length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground">No money transactions yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {transactions
                          .filter((t) => t.type === "deposit" || t.type === "withdrawal" || t.type === "refund")
                          .map((transaction) => (
                            <div
                              key={transaction.id}
                              className="flex items-center justify-between py-3 border-b last:border-0"
                            >
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                  {getTransactionIcon(transaction.type)}
                                </div>
                                <div>
                                  <p className="font-medium">{transaction.description}</p>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <span>{new Date(transaction.date).toLocaleString()}</span>
                                    <div className="flex items-center gap-1">
                                      {getStatusIcon(transaction.status)}
                                      <span className="capitalize">{transaction.status}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className={`font-medium ${getAmountColor(transaction.type, transaction.amount)}`}>
                                {formatAmount(transaction.type, transaction.amount)}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="points">
                    {transactions.filter((t) => t.type === "points_earned" || t.type === "points_used").length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground">No point transactions yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {transactions
                          .filter((t) => t.type === "points_earned" || t.type === "points_used")
                          .map((transaction) => (
                            <div
                              key={transaction.id}
                              className="flex items-center justify-between py-3 border-b last:border-0"
                            >
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                  {getTransactionIcon(transaction.type)}
                                </div>
                                <div>
                                  <p className="font-medium">{transaction.description}</p>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <span>{new Date(transaction.date).toLocaleString()}</span>
                                    <div className="flex items-center gap-1">
                                      {getStatusIcon(transaction.status)}
                                      <span className="capitalize">{transaction.status}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className={`font-medium ${getAmountColor(transaction.type, transaction.amount)}`}>
                                {formatAmount(transaction.type, transaction.amount)}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="payments">
                    {transactions.filter((t) => t.type === "payment").length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground">No payment transactions yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {transactions
                          .filter((t) => t.type === "payment")
                          .map((transaction) => (
                            <div
                              key={transaction.id}
                              className="flex items-center justify-between py-3 border-b last:border-0"
                            >
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                  {getTransactionIcon(transaction.type)}
                                </div>
                                <div>
                                  <p className="font-medium">{transaction.description}</p>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <span>{new Date(transaction.date).toLocaleString()}</span>
                                    <div className="flex items-center gap-1">
                                      {getStatusIcon(transaction.status)}
                                      <span className="capitalize">{transaction.status}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className={`font-medium ${getAmountColor(transaction.type, transaction.amount)}`}>
                                {formatAmount(transaction.type, transaction.amount)}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-[#2580B7]/20">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full bg-[#055294] hover:bg-[#073761]">Send Money</Button>
                <Button className="w-full" variant="outline">
                  Request Payment
                </Button>
                <Button className="w-full" variant="outline">
                  Buy Service Credits
                </Button>
              </CardContent>
            </Card>

            <Card className="border-[#2580B7]/20">
              <CardHeader>
                <CardTitle>Rewards Program</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Current Tier</span>
                    <Badge className="bg-[#055294]">Silver</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Points to Gold</span>
                    <span className="font-medium">500 more</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2.5">
                    <div className="bg-[#055294] h-2.5 rounded-full" style={{ width: "35%" }}></div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Earn points by completing transactions, connecting with professionals, and receiving positive
                    reviews.
                  </div>
                  <div className="space-y-2 mt-4">
                    <h4 className="font-medium">Benefits</h4>
                    <ul className="text-sm space-y-1">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>5% cashback on service purchases</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>Priority customer support</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>Exclusive monthly offers</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-[#2580B7]/20">
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-6 bg-blue-600 rounded"></div>
                      <span>Visa ending in 4242</span>
                    </div>
                    <Badge variant="outline">Default</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-6 bg-red-500 rounded"></div>
                      <span>Mastercard ending in 8888</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full">
                    Add Payment Method
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
