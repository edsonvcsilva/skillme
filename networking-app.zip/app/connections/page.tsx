"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, MessageSquare, UserPlus, Check, X, UserCheck, UserMinus, Users } from "lucide-react"
import { MainLayout } from "@/components/layout/main-layout"
import { useConnection } from "@/lib/connection-context"
import { useAuth } from "@/lib/auth-context"
import { getUserById, users } from "@/lib/data"
import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function ConnectionsPage() {
  const { user: currentUser } = useAuth()
  const {
    connections,
    getConnectionStatus,
    sendConnectionRequest,
    acceptConnectionRequest,
    rejectConnectionRequest,
    removeConnection,
    getPendingRequests,
  } = useConnection()
  const [searchTerm, setSearchTerm] = useState("")
  const router = useRouter()

  if (!currentUser) return null

  // Get all connections for the current user
  const userConnections = connections.filter(
    (conn) => (conn.userId === currentUser.id || conn.connectedUserId === currentUser.id) && conn.status === "accepted",
  )

  // Get connection requests received by the current user
  const pendingRequests = getPendingRequests()

  // Get users who are not connected with the current user for suggestions
  const suggestedUsers = users.filter((u) => {
    if (u.id === currentUser.id) return false
    const status = getConnectionStatus(u.id)
    return status === "none"
  })

  // Filter connections based on search term
  const filteredConnections = userConnections.filter((conn) => {
    const connectedUserId = conn.userId === currentUser.id ? conn.connectedUserId : conn.userId
    const connectedUser = getUserById(connectedUserId)
    if (!connectedUser) return false
    return connectedUser.name.toLowerCase().includes(searchTerm.toLowerCase())
  })

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <h1 className="text-3xl font-bold text-[#073761]">Connections</h1>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search connections..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <Tabs defaultValue="connections" className="mb-8">
          <TabsList className="grid w-full max-w-md grid-cols-3 mb-6">
            <TabsTrigger value="connections">My Connections</TabsTrigger>
            <TabsTrigger value="requests">
              Requests
              {pendingRequests.length > 0 && <Badge className="ml-2 bg-[#055294]">{pendingRequests.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
          </TabsList>
          <TabsContent value="connections">
            {filteredConnections.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No connections yet</h3>
                <p className="text-muted-foreground mb-6">Start connecting with professionals in your industry</p>
                <Button
                  onClick={() => document.querySelector('[data-value="suggestions"]')?.click()}
                  className="bg-[#055294] hover:bg-[#073761]"
                >
                  Find People to Connect
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredConnections.map((conn) => {
                  const connectedUserId = conn.userId === currentUser.id ? conn.connectedUserId : conn.userId
                  const connectedUser = getUserById(connectedUserId)
                  if (!connectedUser) return null

                  return (
                    <Card key={conn.id} className="border-[#2580B7]/20">
                      <CardContent className="p-6">
                        <div className="flex flex-col items-center text-center mb-4">
                          <Avatar className="h-20 w-20 mb-4">
                            <AvatarImage src={connectedUser.avatar || "/placeholder.svg"} alt={connectedUser.name} />
                            <AvatarFallback>
                              {connectedUser.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <h3 className="font-medium text-lg">{connectedUser.name}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{connectedUser.title}</p>
                          <div className="flex flex-wrap justify-center gap-1 mb-2">
                            {connectedUser.skills.slice(0, 2).map((skill, index) => (
                              <Badge key={index} variant="outline" className="border-[#2580B7]/30">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <span>Connected since {new Date(conn.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            className="flex-1 gap-1 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                            onClick={() => router.push(`/messages?userId=${connectedUser.id}`)}
                          >
                            <MessageSquare className="h-4 w-4" />
                            Message
                          </Button>
                          <Link href={`/profile/${connectedUser.id}`} className="flex-1">
                            <Button
                              variant="outline"
                              className="w-full border-[#2580B7]/30 hover:border-[#2580B7] hover:bg-[#2580B7]/10"
                            >
                              View Profile
                            </Button>
                          </Link>
                        </div>
                        <Button
                          variant="ghost"
                          className="w-full mt-2 text-muted-foreground hover:text-destructive"
                          onClick={() => removeConnection(conn.id)}
                        >
                          <UserMinus className="h-4 w-4 mr-2" />
                          Remove Connection
                        </Button>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </TabsContent>
          <TabsContent value="requests">
            {pendingRequests.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <UserCheck className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No pending requests</h3>
                <p className="text-muted-foreground">You don't have any connection requests at the moment</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pendingRequests.map((request) => {
                  const requestUser = getUserById(request.userId)
                  if (!requestUser) return null

                  return (
                    <Card key={request.id} className="border-[#2580B7]/20">
                      <CardContent className="p-6">
                        <div className="flex items-center gap-4 mb-4">
                          <Avatar>
                            <AvatarImage src={requestUser.avatar || "/placeholder.svg"} alt={requestUser.name} />
                            <AvatarFallback>
                              {requestUser.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">{requestUser.name}</h3>
                            <p className="text-sm text-muted-foreground">{requestUser.title}</p>
                          </div>
                        </div>
                        <p className="text-sm mb-4">
                          I'd like to connect with you to discuss potential collaboration opportunities.
                        </p>
                        <div className="flex gap-2">
                          <Button
                            className="flex-1 gap-1 bg-[#055294] hover:bg-[#073761]"
                            onClick={() => acceptConnectionRequest(request.id)}
                          >
                            <Check className="h-4 w-4" />
                            Accept
                          </Button>
                          <Button
                            variant="outline"
                            className="flex-1 gap-1"
                            onClick={() => rejectConnectionRequest(request.id)}
                          >
                            <X className="h-4 w-4" />
                            Decline
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </TabsContent>
          <TabsContent value="suggestions">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {suggestedUsers.slice(0, 8).map((suggestedUser) => (
                <Card key={suggestedUser.id} className="border-[#2580B7]/20">
                  <CardContent className="p-6 text-center">
                    <Avatar className="h-16 w-16 mx-auto mb-4">
                      <AvatarImage src={suggestedUser.avatar || "/placeholder.svg"} alt={suggestedUser.name} />
                      <AvatarFallback>
                        {suggestedUser.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <h3 className="font-medium mb-1">{suggestedUser.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{suggestedUser.title}</p>
                    <p className="text-xs text-muted-foreground mb-4">
                      {Math.floor(Math.random() * 10) + 2} mutual connections
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full gap-1 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                      onClick={() => sendConnectionRequest(suggestedUser.id)}
                    >
                      <UserPlus className="h-4 w-4" />
                      Connect
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
