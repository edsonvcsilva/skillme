"use client"

import { MainLayout } from "@/components/layout/main-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserPlus, MessageSquare, Star, Bell, Check, X, Calendar, Briefcase, Eye } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useConnection } from "@/lib/connection-context"
import { getUserById } from "@/lib/data"
import Link from "next/link"

export default function NotificationsPage() {
  const { user: currentUser } = useAuth()
  const { getPendingRequests, acceptConnectionRequest, rejectConnectionRequest } = useConnection()

  if (!currentUser) return null

  const pendingRequests = getPendingRequests()

  // Mock notifications data
  const notifications = [
    {
      id: "1",
      type: "message",
      userId: "2",
      content: "sent you a message",
      read: false,
      createdAt: "2025-04-13T10:30:00",
    },
    {
      id: "2",
      type: "review",
      userId: "3",
      content: "left a 5-star review on your Web Development service",
      read: false,
      createdAt: "2025-04-12T15:45:00",
    },
    {
      id: "3",
      type: "connection",
      userId: "4",
      content: "accepted your connection request",
      read: true,
      createdAt: "2025-04-11T09:15:00",
    },
    {
      id: "4",
      type: "service",
      userId: "5",
      content: "added a new service: Content Writing",
      read: true,
      createdAt: "2025-04-10T14:20:00",
    },
    {
      id: "5",
      type: "system",
      content: "Welcome to ConnectPro! Complete your profile to get started.",
      read: true,
      createdAt: "2025-04-09T08:00:00",
    },
  ]

  const unreadCount = notifications.filter((n) => !n.read).length

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "message":
        return <MessageSquare className="h-5 w-5 text-[#055294]" />
      case "review":
        return <Star className="h-5 w-5 text-[#055294]" />
      case "connection":
        return <UserPlus className="h-5 w-5 text-[#055294]" />
      case "service":
        return <Briefcase className="h-5 w-5 text-[#055294]" />
      default:
        return <Bell className="h-5 w-5 text-[#055294]" />
    }
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <h1 className="text-3xl font-bold text-[#073761]">Notifications</h1>
          <Button variant="outline">Mark All as Read</Button>
        </div>

        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="grid w-full max-w-md grid-cols-3 mb-6">
            <TabsTrigger value="all">
              All
              {unreadCount > 0 && <Badge className="ml-2 bg-[#055294]">{unreadCount}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="requests">
              Requests
              {pendingRequests.length > 0 && <Badge className="ml-2 bg-[#055294]">{pendingRequests.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="unread">
              Unread
              {unreadCount > 0 && <Badge className="ml-2 bg-[#055294]">{unreadCount}</Badge>}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <div className="space-y-4">
              {notifications.map((notification) => {
                const notificationUser = notification.userId ? getUserById(notification.userId) : null

                return (
                  <Card
                    key={notification.id}
                    className={notification.read ? "border-[#2580B7]/10" : "border-[#055294]"}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-full bg-[#2580B7]/10 flex items-center justify-center shrink-0">
                          {getNotificationIcon(notification.type)}
                        </div>

                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <p>
                                {notificationUser ? (
                                  <>
                                    <Link
                                      href={`/profile/${notificationUser.id}`}
                                      className="font-medium hover:text-[#055294]"
                                    >
                                      {notificationUser.name}
                                    </Link>{" "}
                                    {notification.content}
                                  </>
                                ) : (
                                  notification.content
                                )}
                              </p>
                              <div className="flex items-center gap-2 mt-1">
                                <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">
                                  {new Date(notification.createdAt).toLocaleString()}
                                </span>
                              </div>
                            </div>

                            {!notification.read && <Badge className="bg-[#055294]">New</Badge>}
                          </div>

                          {notification.type === "message" && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                            >
                              <MessageSquare className="h-4 w-4 mr-2" />
                              Reply
                            </Button>
                          )}

                          {notification.type === "review" && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              View Review
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="requests">
            {pendingRequests.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <UserPlus className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No pending requests</h3>
                <p className="text-muted-foreground">You don't have any connection requests at the moment</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingRequests.map((request) => {
                  const requestUser = getUserById(request.userId)
                  if (!requestUser) return null

                  return (
                    <Card key={request.id} className="border-[#055294]">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <Avatar>
                            <AvatarImage src={requestUser.avatar || "/placeholder.svg"} alt={requestUser.name} />
                            <AvatarFallback>
                              {requestUser.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-start justify-between">
                              <div>
                                <p>
                                  <Link
                                    href={`/profile/${requestUser.id}`}
                                    className="font-medium hover:text-[#055294]"
                                  >
                                    {requestUser.name}
                                  </Link>{" "}
                                  sent you a connection request
                                </p>
                                <p className="text-sm text-muted-foreground mt-1">{requestUser.title}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">
                                    {new Date(request.createdAt).toLocaleString()}
                                  </span>
                                </div>
                              </div>
                              <Badge className="bg-[#055294]">New</Badge>
                            </div>
                            <div className="flex gap-2 mt-3">
                              <Button
                                className="gap-1 bg-[#055294] hover:bg-[#073761]"
                                onClick={() => acceptConnectionRequest(request.id)}
                              >
                                <Check className="h-4 w-4" />
                                Accept
                              </Button>
                              <Button
                                variant="outline"
                                className="gap-1"
                                onClick={() => rejectConnectionRequest(request.id)}
                              >
                                <X className="h-4 w-4" />
                                Decline
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="unread">
            {unreadCount === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <Bell className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No unread notifications</h3>
                <p className="text-muted-foreground">You're all caught up!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {notifications
                  .filter((n) => !n.read)
                  .map((notification) => {
                    const notificationUser = notification.userId ? getUserById(notification.userId) : null

                    return (
                      <Card key={notification.id} className="border-[#055294]">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-4">
                            <div className="w-10 h-10 rounded-full bg-[#2580B7]/10 flex items-center justify-center shrink-0">
                              {getNotificationIcon(notification.type)}
                            </div>

                            <div className="flex-1">
                              <div className="flex items-start justify-between gap-4">
                                <div>
                                  <p>
                                    {notificationUser ? (
                                      <>
                                        <Link
                                          href={`/profile/${notificationUser.id}`}
                                          className="font-medium hover:text-[#055294]"
                                        >
                                          {notificationUser.name}
                                        </Link>{" "}
                                        {notification.content}
                                      </>
                                    ) : (
                                      notification.content
                                    )}
                                  </p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      {new Date(notification.createdAt).toLocaleString()}
                                    </span>
                                  </div>
                                </div>

                                <Badge className="bg-[#055294]">New</Badge>
                              </div>

                              {notification.type === "message" && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="mt-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                                >
                                  <MessageSquare className="h-4 w-4 mr-2" />
                                  Reply
                                </Button>
                              )}

                              {notification.type === "review" && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="mt-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                                >
                                  <Eye className="h-4 w-4 mr-2" />
                                  View Review
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
