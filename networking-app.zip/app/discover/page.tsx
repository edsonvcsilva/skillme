"use client"

import { useState, useEffect } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, MapPin, ThumbsUp, ThumbsDown, Heart } from "lucide-react"
import { useConnection } from "@/lib/connection-context"
import { useAuth } from "@/lib/auth-context"
import { users } from "@/lib/data"
import { motion, AnimatePresence } from "@/lib/motion"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

export default function DiscoverPage() {
  const { user: currentUser } = useAuth()
  const { getConnectionStatus, sendConnectionRequest } = useConnection()
  const [potentialConnections, setPotentialConnections] = useState<typeof users>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [direction, setDirection] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (currentUser) {
      // Filter users who are not connected with the current user
      const filtered = users.filter((u) => {
        if (u.id === currentUser.id) return false
        const status = getConnectionStatus(u.id)
        return status === "none"
      })

      // Shuffle the array for more randomness
      const shuffled = [...filtered].sort(() => Math.random() - 0.5)
      setPotentialConnections(shuffled)
    }
  }, [currentUser, getConnectionStatus])

  const currentProfile = potentialConnections[currentIndex]

  const handleSwipe = (dir: string) => {
    if (!currentProfile) return

    setDirection(dir)

    if (dir === "right") {
      sendConnectionRequest(currentProfile.id)
      toast({
        title: "Connection Request Sent",
        description: `You sent a connection request to ${currentProfile.name}`,
      })
    }

    // Wait for animation to complete before changing index
    setTimeout(() => {
      setCurrentIndex((prev) => prev + 1)
      setDirection(null)
    }, 300)
  }

  if (!currentUser || !potentialConnections.length) {
    return (
      <MainLayout>
        <div className="container py-8 flex flex-col items-center justify-center min-h-[60vh]">
          <div className="w-20 h-20 rounded-full bg-[#2580B7]/10 flex items-center justify-center mb-6">
            <Heart className="h-10 w-10 text-[#055294]" />
          </div>
          <h2 className="text-2xl font-bold mb-2 text-center">No more profiles to discover</h2>
          <p className="text-muted-foreground text-center mb-6">
            We've run out of new professionals to show you. Check back later!
          </p>
          <Link href="/">
            <Button className="bg-[#055294] hover:bg-[#073761]">Back to Home</Button>
          </Link>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col items-center">
          <h1 className="text-3xl font-bold mb-8 text-[#073761]">Discover Professionals</h1>

          <div className="w-full max-w-md relative min-h-[60vh] flex items-center justify-center">
            <AnimatePresence>
              {currentProfile && (
                <motion.div
                  key={currentProfile.id}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{
                    x: direction === "left" ? -300 : direction === "right" ? 300 : 0,
                    opacity: 0,
                    transition: { duration: 0.3 },
                  }}
                  transition={{ duration: 0.3 }}
                  className="w-full absolute"
                >
                  <Card className="overflow-hidden border-[#2580B7]/20 shadow-lg">
                    <div className="h-64 bg-gradient-blue relative">
                      {currentProfile.coverImage && (
                        <img
                          src={currentProfile.coverImage || "/placeholder.svg"}
                          alt="Cover"
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <CardContent className="p-6 -mt-16 relative">
                      <div className="flex flex-col items-center text-center">
                        <Avatar className="h-32 w-32 border-4 border-background mb-4">
                          <AvatarImage src={currentProfile.avatar || "/placeholder.svg"} alt={currentProfile.name} />
                          <AvatarFallback>
                            {currentProfile.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <h2 className="text-2xl font-bold mb-1">{currentProfile.name}</h2>
                        <p className="text-lg text-muted-foreground mb-2">{currentProfile.title}</p>

                        <div className="flex items-center gap-2 mb-3">
                          <Badge variant="outline" className="gap-1 border-[#2580B7]/30">
                            <Star className="h-3.5 w-3.5 fill-[#055294] text-[#055294]" />
                            {currentProfile.rating}
                          </Badge>
                          <Badge variant="outline" className="gap-1 border-[#2580B7]/30">
                            <MapPin className="h-3.5 w-3.5" />
                            {currentProfile.location}
                          </Badge>
                        </div>

                        <p className="mb-4 text-sm">{currentProfile.bio}</p>

                        <div className="flex flex-wrap gap-2 justify-center mb-6">
                          {currentProfile.skills.slice(0, 5).map((skill, index) => (
                            <Badge key={index} variant="secondary">
                              {skill}
                            </Badge>
                          ))}
                        </div>

                        <Link href={`/profile/${currentProfile.id}`} className="w-full">
                          <Button variant="outline" className="w-full mb-4">
                            View Full Profile
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex justify-center gap-8 mt-8 absolute bottom-[-80px]">
              <Button
                size="lg"
                variant="outline"
                className="h-20 w-20 rounded-full border-4 border-destructive text-destructive hover:bg-destructive hover:text-white shadow-lg"
                onClick={() => handleSwipe("left")}
              >
                <ThumbsDown className="h-10 w-10" />
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="h-20 w-20 rounded-full border-4 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white shadow-lg"
                onClick={() => handleSwipe("right")}
              >
                <ThumbsUp className="h-10 w-10" />
              </Button>
            </div>
          </div>

          <div className="mt-32 text-center">
            <p className="text-muted-foreground mb-2">
              {currentIndex + 1} of {potentialConnections.length} profiles
            </p>
            <p className="text-sm text-muted-foreground">Swipe right to connect, swipe left to skip</p>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
