"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Users, Briefcase } from "lucide-react"
import { ServiceCard } from "@/components/service-card"
import { UserCard } from "@/components/user-card"
import { MainLayout } from "@/components/layout/main-layout"
import { useAuth } from "@/lib/auth-context"
import { services, users } from "@/lib/data"

export default function Home() {
  const { user } = useAuth()

  // Filter out the current user from the users list
  const otherUsers = users.filter((u) => u.id !== user?.id).slice(0, 4)
  const featuredServices = services.slice(0, 3)

  return (
    <MainLayout>
      <div className="py-8">
        <div className="container">
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold">Welcome{user ? `, ${user.name.split(" ")[0]}` : ""}</h2>
              <Link href="/services">
                <Button>Browse All Services</Button>
              </Link>
            </div>
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Briefcase className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Offer Services</h3>
                    <p className="text-sm text-muted-foreground">
                      List your skills and services for others to discover
                    </p>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Build Connections</h3>
                    <p className="text-sm text-muted-foreground">Connect with professionals in your industry</p>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Star className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Earn Reputation</h3>
                    <p className="text-sm text-muted-foreground">Get rated for your services and build trust</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Featured Services</h2>
              <Link href="/services">
                <Button variant="outline">View All</Button>
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredServices.map((service) => {
                const serviceUser = users.find((u) => u.id === service.userId)!
                return (
                  <ServiceCard
                    key={service.id}
                    id={service.id}
                    title={service.title}
                    description={service.description}
                    rating={service.rating}
                    reviewCount={service.reviewCount}
                    category={service.category}
                    userName={serviceUser.name}
                    userAvatar={serviceUser.avatar}
                    image={service.image}
                  />
                )
              })}
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Top Professionals</h2>
              <Link href="/professionals">
                <Button variant="outline">View All</Button>
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {otherUsers.map((user) => (
                <UserCard
                  key={user.id}
                  id={user.id}
                  name={user.name}
                  title={user.title}
                  rating={user.rating}
                  connectionCount={user.connectionCount}
                  avatar={user.avatar}
                />
              ))}
            </div>
          </section>
        </div>
      </div>
    </MainLayout>
  )
}
