"use client"

import { useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Camera, Bell, Lock, User, Shield, Upload } from "lucide-react"

export default function SettingsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [saving, setSaving] = useState(false)

  if (!user) return null

  const handleSave = () => {
    setSaving(true)

    // Simulate API call
    setTimeout(() => {
      setSaving(false)
      toast({
        title: "Settings saved",
        description: "Your settings have been saved successfully.",
      })
    }, 1000)
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <h1 className="text-3xl font-bold text-[#073761]">Settings</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[250px_1fr] gap-8">
          <Card className="h-fit lg:sticky lg:top-24">
            <CardContent className="p-6">
              <Tabs defaultValue="profile" orientation="vertical" className="w-full">
                <TabsList className="flex flex-col h-auto items-stretch gap-1">
                  <TabsTrigger value="profile" className="justify-start">
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </TabsTrigger>
                  <TabsTrigger value="account" className="justify-start">
                    <Lock className="h-4 w-4 mr-2" />
                    Account
                  </TabsTrigger>
                  <TabsTrigger value="notifications" className="justify-start">
                    <Bell className="h-4 w-4 mr-2" />
                    Notifications
                  </TabsTrigger>
                  <TabsTrigger value="privacy" className="justify-start">
                    <Shield className="h-4 w-4 mr-2" />
                    Privacy
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardContent>
          </Card>

          <div className="space-y-8">
            <Tabs defaultValue="profile">
              <TabsContent value="profile">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>
                      Update your profile information and how others see you on the platform
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex flex-col md:flex-row gap-6 items-start">
                      <div className="flex flex-col items-center gap-2">
                        <Avatar className="h-24 w-24">
                          <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                          <AvatarFallback>
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <Button variant="outline" size="sm" className="gap-2">
                          <Camera className="h-4 w-4" />
                          Change Photo
                        </Button>
                      </div>

                      <div className="flex-1 grid gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input id="name" defaultValue={user.name} />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="title">Professional Title</Label>
                          <Input id="title" defaultValue={user.title} />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="location">Location</Label>
                          <Input id="location" defaultValue={user.location} />
                        </div>
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea id="bio" rows={4} defaultValue={user.bio} />
                      <p className="text-xs text-muted-foreground">
                        Brief description for your profile. URLs are hyperlinked.
                      </p>
                    </div>

                    <div className="grid gap-2">
                      <Label>Skills</Label>
                      <div className="flex flex-wrap gap-2">
                        {user.skills.map((skill, index) => (
                          <div key={index} className="flex items-center gap-2 bg-muted rounded-md px-3 py-1">
                            <span>{skill}</span>
                            <button className="text-muted-foreground hover:text-foreground">×</button>
                          </div>
                        ))}
                        <Input className="w-32" placeholder="Add skill..." />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="cover">Cover Image</Label>
                      <div className="border rounded-md p-4 flex flex-col items-center justify-center gap-4 h-40 bg-muted/50">
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          Drag and drop an image, or <span className="text-[#055294]">browse</span>
                        </p>
                        <p className="text-xs text-muted-foreground">Recommended size: 1200 x 300px</p>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-[#055294] hover:bg-[#073761]" onClick={handleSave} disabled={saving}>
                        {saving ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="account">
                <Card>
                  <CardHeader>
                    <CardTitle>Account Settings</CardTitle>
                    <CardDescription>Manage your account settings and security preferences</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input id="email" type="email" defaultValue={user.email} />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="username">Username</Label>
                        <Input id="username" defaultValue={user.username} />
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium mb-4">Change Password</h3>
                      <div className="grid gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="current-password">Current Password</Label>
                          <Input id="current-password" type="password" />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="new-password">New Password</Label>
                          <Input id="new-password" type="password" />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="confirm-password">Confirm New Password</Label>
                          <Input id="confirm-password" type="password" />
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium mb-4">Danger Zone</h3>
                      <div className="grid gap-4">
                        <div className="flex flex-col gap-2">
                          <Button variant="destructive">Deactivate Account</Button>
                          <p className="text-xs text-muted-foreground">
                            Temporarily disable your account. You can reactivate it anytime.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-[#055294] hover:bg-[#073761]" onClick={handleSave} disabled={saving}>
                        {saving ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notifications">
                <Card>
                  <CardHeader>
                    <CardTitle>Notification Preferences</CardTitle>
                    <CardDescription>Manage how you receive notifications from the platform</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Email Notifications</h3>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="email-connections">Connection Requests</Label>
                          <p className="text-sm text-muted-foreground">
                            Receive emails when someone sends you a connection request
                          </p>
                        </div>
                        <Switch id="email-connections" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="email-messages">Messages</Label>
                          <p className="text-sm text-muted-foreground">Receive emails when you get new messages</p>
                        </div>
                        <Switch id="email-messages" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="email-reviews">Reviews</Label>
                          <p className="text-sm text-muted-foreground">
                            Receive emails when someone leaves a review on your services
                          </p>
                        </div>
                        <Switch id="email-reviews" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="email-marketing">Marketing</Label>
                          <p className="text-sm text-muted-foreground">
                            Receive emails about new features and promotions
                          </p>
                        </div>
                        <Switch id="email-marketing" />
                      </div>
                    </div>

                    <div className="border-t pt-6 space-y-4">
                      <h3 className="text-lg font-medium">Push Notifications</h3>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="push-all">Enable Push Notifications</Label>
                          <p className="text-sm text-muted-foreground">Receive notifications on your device</p>
                        </div>
                        <Switch id="push-all" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="push-connections">Connection Activity</Label>
                          <p className="text-sm text-muted-foreground">
                            Notifications for connection requests and acceptances
                          </p>
                        </div>
                        <Switch id="push-connections" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="push-messages">Messages</Label>
                          <p className="text-sm text-muted-foreground">Notifications for new messages</p>
                        </div>
                        <Switch id="push-messages" defaultChecked />
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-[#055294] hover:bg-[#073761]" onClick={handleSave} disabled={saving}>
                        {saving ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="privacy">
                <Card>
                  <CardHeader>
                    <CardTitle>Privacy Settings</CardTitle>
                    <CardDescription>Control your privacy and visibility on the platform</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Profile Visibility</h3>

                      <div className="grid gap-2">
                        <Label htmlFor="profile-visibility">Who can see your profile</Label>
                        <Select defaultValue="everyone">
                          <SelectTrigger id="profile-visibility">
                            <SelectValue placeholder="Select visibility" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="everyone">Everyone</SelectItem>
                            <SelectItem value="connections">Connections only</SelectItem>
                            <SelectItem value="nobody">Nobody</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="connection-visibility">Who can see your connections</Label>
                        <Select defaultValue="everyone">
                          <SelectTrigger id="connection-visibility">
                            <SelectValue placeholder="Select visibility" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="everyone">Everyone</SelectItem>
                            <SelectItem value="connections">Connections only</SelectItem>
                            <SelectItem value="nobody">Nobody</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="border-t pt-6 space-y-4">
                      <h3 className="text-lg font-medium">Connection Settings</h3>

                      <div className="grid gap-2">
                        <Label htmlFor="connection-requests">Who can send you connection requests</Label>
                        <Select defaultValue="everyone">
                          <SelectTrigger id="connection-requests">
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="everyone">Everyone</SelectItem>
                            <SelectItem value="mutual">People with mutual connections</SelectItem>
                            <SelectItem value="nobody">Nobody</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="connection-approval">Require approval for connection requests</Label>
                          <p className="text-sm text-muted-foreground">
                            You'll need to approve all connection requests
                          </p>
                        </div>
                        <Switch id="connection-approval" defaultChecked />
                      </div>
                    </div>

                    <div className="border-t pt-6 space-y-4">
                      <h3 className="text-lg font-medium">Activity Settings</h3>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="online-status">Show when you're online</Label>
                          <p className="text-sm text-muted-foreground">
                            Let others see when you're active on the platform
                          </p>
                        </div>
                        <Switch id="online-status" defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="activity-visibility">Share your activity with connections</Label>
                          <p className="text-sm text-muted-foreground">Let your connections see your recent activity</p>
                        </div>
                        <Switch id="activity-visibility" defaultChecked />
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button className="bg-[#055294] hover:bg-[#073761]" onClick={handleSave} disabled={saving}>
                        {saving ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}
