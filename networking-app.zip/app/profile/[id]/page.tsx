"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ServiceCard } from "@/components/service-card"
import { ProminentConnectionButtons } from "@/components/profile/prominent-connection-buttons"
import { Star, MessageSquare, Users, MapPin, Briefcase, Calendar, Edit, Settings } from "lucide-react"
import { MainLayout } from "@/components/layout/main-layout"
import { useAuth } from "@/lib/auth-context"
import { getUserById, getServicesByUserId, users } from "@/lib/data"
import { useParams } from "next/navigation"
import { notFound } from "next/navigation"

export default function ProfilePage() {
  const { user: currentUser } = useAuth()
  const params = useParams()
  const userId = params.id as string

  // If no ID is provided, show the current user's profile
  const profileUser = userId ? getUserById(userId) : currentUser

  if (!profileUser) {
    notFound()
  }

  const isOwnProfile = currentUser?.id === profileUser.id
  const userServices = getServicesByUserId(profileUser.id)

  return (
    <MainLayout>
      <div className="container py-8">
        <Card className="mb-8 border-[#2580B7]/20 relative">
          {!isOwnProfile && <ProminentConnectionButtons userId={profileUser.id} userName={profileUser.name} />}
          <div className="h-48 bg-gradient-blue relative">
            {profileUser.coverImage && (
              <img
                src={profileUser.coverImage || "/placeholder.svg"}
                alt="Cover"
                className="w-full h-full object-cover"
                onError={(e) => {
                  // Remove the image if it fails to load
                  ;(e.target as HTMLImageElement).style.display = "none"
                }}
              />
            )}
          </div>
          <CardContent className="p-6 -mt-12">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex flex-col items-center md:items-start gap-4">
                <Avatar className="h-24 w-24 border-4 border-background">
                  <AvatarImage
                    src={profileUser.avatar || "/placeholder.svg"}
                    alt={profileUser.name}
                    onError={(e) => {
                      // Fallback if avatar fails to load
                      ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=96&width=96"
                    }}
                  />
                  <AvatarFallback>
                    {profileUser.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                {isOwnProfile && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
                    >
                      <Edit className="h-4 w-4" />
                      Edit Profile
                    </Button>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Settings className="h-4 w-4" />
                      Settings
                    </Button>
                  </div>
                )}
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-4">
                  <div>
                    <h1 className="text-2xl font-bold">{profileUser.name}</h1>
                    <p className="text-muted-foreground">{profileUser.title}</p>
                  </div>
                  <div className="flex flex-wrap justify-center md:justify-end gap-2">
                    <Badge variant="outline" className="gap-1 border-[#2580B7]/30">
                      <Star className="h-3.5 w-3.5 fill-[#055294] text-[#055294]" />
                      {profileUser.rating} ({profileUser.reviewCount} reviews)
                    </Badge>
                    <Badge variant="outline" className="gap-1 border-[#2580B7]/30">
                      <Users className="h-3.5 w-3.5" />
                      {profileUser.connectionCount} connections
                    </Badge>
                    <Badge variant="outline" className="gap-1 border-[#2580B7]/30">
                      <MapPin className="h-3.5 w-3.5" />
                      {profileUser.location}
                    </Badge>
                  </div>
                </div>
                <p className="mb-4">{profileUser.bio}</p>
                <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                  {profileUser.skills.map((skill, index) => (
                    <Badge key={index} className="bg-[#2580B7]/10 text-[#055294] hover:bg-[#2580B7]/20">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="services" className="mb-8">
          <TabsList className="grid grid-cols-4 w-full max-w-md mb-6">
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="connections">Connections</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>
          <TabsContent value="services">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-[#073761]">{isOwnProfile ? "My Services" : "Services"}</h2>
              {isOwnProfile && <Button className="bg-[#055294] hover:bg-[#073761]">Add New Service</Button>}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userServices.map((service) => (
                <ServiceCard
                  key={service.id}
                  id={service.id}
                  title={service.title}
                  description={service.description}
                  rating={service.rating}
                  reviewCount={service.reviewCount}
                  category={service.category}
                  userName={profileUser.name}
                  userAvatar={profileUser.avatar}
                  image={service.image}
                />
              ))}
              {isOwnProfile && userServices.length < 3 && (
                <Card className="border-dashed border-[#2580B7]/30 flex items-center justify-center h-full min-h-[300px]">
                  <Button
                    variant="ghost"
                    className="flex flex-col gap-2 h-auto py-8 text-[#055294] hover:bg-[#2580B7]/10"
                  >
                    <div className="w-12 h-12 rounded-full bg-[#2580B7]/10 flex items-center justify-center">
                      <Briefcase className="h-6 w-6 text-[#055294]" />
                    </div>
                    <span>Add New Service</span>
                  </Button>
                </Card>
              )}
            </div>
          </TabsContent>
          <TabsContent value="reviews">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-[#073761]">Reviews</h2>
              <div className="flex items-center gap-2">
                <Star className="h-5 w-5 fill-[#055294] text-[#055294]" />
                <span className="font-medium">{profileUser.rating}</span>
                <span className="text-muted-foreground">({profileUser.reviewCount} reviews)</span>
              </div>
            </div>
            <div className="space-y-6">
              {[1, 2, 3].map((i) => {
                const reviewer = users[i % users.length]
                return (
                  <Card key={i} className="border-[#2580B7]/20">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Avatar>
                          <AvatarImage src={reviewer.avatar || "/placeholder.svg"} alt={reviewer.name} />
                          <AvatarFallback>
                            {reviewer.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <h3 className="font-medium">{reviewer.name}</h3>
                              <p className="text-sm text-muted-foreground">Web Development</p>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                              <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                              <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                              <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                              <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                            </div>
                          </div>
                          <p className="text-sm">
                            {profileUser.name} did an excellent job on our project. Very professional, responsive, and
                            delivered on time. The quality of work exceeded our expectations.
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">March {15 - i}, 2025</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
          <TabsContent value="connections">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-[#073761]">Connections</h2>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <span className="font-medium">{profileUser.connectionCount} connections</span>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {users
                .filter((u) => u.id !== profileUser.id)
                .slice(0, 6)
                .map((connection) => (
                  <Card key={connection.id} className="border-[#2580B7]/20">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src={connection.avatar || "/placeholder.svg"} alt={connection.name} />
                          <AvatarFallback>
                            {connection.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <h3 className="font-medium">{connection.name}</h3>
                          <p className="text-sm text-muted-foreground">{connection.title}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-[#055294] hover:bg-[#2580B7]/10 hover:text-[#073761]"
                        >
                          <MessageSquare className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>
          <TabsContent value="activity">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-[#073761]">Recent Activity</h2>
            </div>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Card key={i} className="border-[#2580B7]/20">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-[#2580B7]/10 flex items-center justify-center shrink-0">
                        {i % 3 === 0 ? (
                          <Star className="h-5 w-5 text-[#055294]" />
                        ) : i % 3 === 1 ? (
                          <Users className="h-5 w-5 text-[#055294]" />
                        ) : (
                          <Briefcase className="h-5 w-5 text-[#055294]" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm">
                          {i % 3 === 0
                            ? `Received a 5-star review from ${users[i % users.length].name}`
                            : i % 3 === 1
                              ? `Connected with ${users[(i + 1) % users.length].name}`
                              : `Added a new service: ${userServices[i % userServices.length]?.title || "UI/UX Design"}`}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">March {15 - i}, 2025</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
