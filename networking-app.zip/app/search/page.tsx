"use client"

import type React from "react"

import { useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { ServiceCard } from "@/components/service-card"
import { UserCard } from "@/components/user-card"
import { SearchIcon, Filter, SlidersHorizontal } from "lucide-react"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { users, services } from "@/lib/data"

export default function SearchPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [searchType, setSearchType] = useState("all")
  const [minRating, setMinRating] = useState(4.0)
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedSkills, setSelectedSkills] = useState<string[]>([])

  // Get unique categories from services
  const categories = Array.from(new Set(services.map((service) => service.category)))

  // Get unique skills from users
  const skills = Array.from(new Set(users.flatMap((user) => user.skills))).slice(0, 12)

  // Filter users based on search criteria
  const filteredUsers = users.filter((user) => {
    if (searchType !== "all" && searchType !== "users") return false

    const matchesSearch =
      searchTerm === "" ||
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.bio.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesRating = user.rating >= minRating

    const matchesSkills = selectedSkills.length === 0 || selectedSkills.some((skill) => user.skills.includes(skill))

    return matchesSearch && matchesRating && matchesSkills
  })

  // Filter services based on search criteria
  const filteredServices = services.filter((service) => {
    if (searchType !== "all" && searchType !== "services") return false

    const matchesSearch =
      searchTerm === "" ||
      service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesRating = service.rating >= minRating

    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(service.category)

    return matchesSearch && matchesRating && matchesCategory
  })

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Search is already reactive, but we could add additional logic here
  }

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const toggleSkill = (skill: string) => {
    setSelectedSkills((prev) => (prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]))
  }

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col items-center mb-8">
          <h1 className="text-3xl font-bold text-[#073761] mb-6">Search</h1>

          <form onSubmit={handleSearch} className="w-full max-w-3xl flex gap-2 mb-6">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-2.5 top-2.5 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search for professionals, services..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <SlidersHorizontal className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>Refine your search results</SheetDescription>
                </SheetHeader>
                <div className="grid gap-6 py-4">
                  <div className="grid gap-2">
                    <Label>Search Type</Label>
                    <Select value={searchType} onValueChange={setSearchType}>
                      <SelectTrigger>
                        <SelectValue placeholder="All" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="users">Professionals</SelectItem>
                        <SelectItem value="services">Services</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label>Minimum Rating</Label>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Rating: {minRating.toFixed(1)}</span>
                    </div>
                    <Slider
                      value={[minRating]}
                      min={1}
                      max={5}
                      step={0.1}
                      onValueChange={(value) => setMinRating(value[0])}
                    />
                  </div>

                  {(searchType === "all" || searchType === "services") && (
                    <div className="grid gap-2">
                      <Label>Categories</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {categories.map((category) => (
                          <div key={category} className="flex items-center space-x-2">
                            <Checkbox
                              id={`category-${category}`}
                              checked={selectedCategories.includes(category)}
                              onCheckedChange={() => toggleCategory(category)}
                            />
                            <label
                              htmlFor={`category-${category}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {category}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {(searchType === "all" || searchType === "users") && (
                    <div className="grid gap-2">
                      <Label>Skills</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {skills.map((skill) => (
                          <div key={skill} className="flex items-center space-x-2">
                            <Checkbox
                              id={`skill-${skill}`}
                              checked={selectedSkills.includes(skill)}
                              onCheckedChange={() => toggleSkill(skill)}
                            />
                            <label
                              htmlFor={`skill-${skill}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {skill}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="bg-[#055294] hover:bg-[#073761]"
                    onClick={() => document.querySelector("[data-radix-collection-item]")?.click()}
                  >
                    Apply Filters
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
            <Button type="submit" className="bg-[#055294] hover:bg-[#073761]">
              <SearchIcon className="h-4 w-4 mr-2" />
              Search
            </Button>
          </form>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Filter className="h-4 w-4" />
            <span>
              {selectedCategories.length > 0 && `Categories: ${selectedCategories.join(", ")} `}
              {selectedSkills.length > 0 && `Skills: ${selectedSkills.join(", ")} `}
              {minRating > 1 && `Min Rating: ${minRating.toFixed(1)}`}
              {selectedCategories.length === 0 && selectedSkills.length === 0 && minRating <= 1 && "No filters applied"}
            </span>
          </div>
        </div>

        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="grid w-full max-w-md grid-cols-3 mb-6 mx-auto">
            <TabsTrigger value="all">All Results</TabsTrigger>
            <TabsTrigger value="professionals">Professionals</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            {filteredUsers.length === 0 && filteredServices.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <SearchIcon className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No results found</h3>
                <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setMinRating(1)
                    setSelectedCategories([])
                    setSelectedSkills([])
                  }}
                >
                  Clear All Filters
                </Button>
              </div>
            ) : (
              <>
                {filteredUsers.length > 0 && (
                  <div className="mb-8">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-bold text-[#073761]">Professionals</h2>
                      <Button
                        variant="link"
                        onClick={() => document.querySelector('[data-value="professionals"]')?.click()}
                      >
                        View All
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      {filteredUsers.slice(0, 4).map((user) => (
                        <UserCard
                          key={user.id}
                          id={user.id}
                          name={user.name}
                          title={user.title}
                          rating={user.rating}
                          connectionCount={user.connectionCount}
                          avatar={user.avatar}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {filteredServices.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-bold text-[#073761]">Services</h2>
                      <Button variant="link" onClick={() => document.querySelector('[data-value="services"]')?.click()}>
                        View All
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredServices.slice(0, 3).map((service) => {
                        const serviceUser = users.find((u) => u.id === service.userId)!
                        return (
                          <ServiceCard
                            key={service.id}
                            id={service.id}
                            title={service.title}
                            description={service.description}
                            rating={service.rating}
                            reviewCount={service.reviewCount}
                            category={service.category}
                            userName={serviceUser.name}
                            userAvatar={serviceUser.avatar}
                            image={service.image}
                          />
                        )
                      })}
                    </div>
                  </div>
                )}
              </>
            )}
          </TabsContent>

          <TabsContent value="professionals">
            {filteredUsers.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <SearchIcon className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No professionals found</h3>
                <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setMinRating(1)
                    setSelectedSkills([])
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredUsers.map((user) => (
                  <UserCard
                    key={user.id}
                    id={user.id}
                    name={user.name}
                    title={user.title}
                    rating={user.rating}
                    connectionCount={user.connectionCount}
                    avatar={user.avatar}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="services">
            {filteredServices.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#2580B7]/10 flex items-center justify-center mx-auto mb-4">
                  <SearchIcon className="h-8 w-8 text-[#055294]" />
                </div>
                <h3 className="text-lg font-medium mb-2">No services found</h3>
                <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setMinRating(1)
                    setSelectedCategories([])
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredServices.map((service) => {
                  const serviceUser = users.find((u) => u.id === service.userId)!
                  return (
                    <ServiceCard
                      key={service.id}
                      id={service.id}
                      title={service.title}
                      description={service.description}
                      rating={service.rating}
                      reviewCount={service.reviewCount}
                      category={service.category}
                      userName={serviceUser.name}
                      userAvatar={serviceUser.avatar}
                      image={service.image}
                    />
                  )
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
