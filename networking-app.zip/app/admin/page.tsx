"use client"

import { useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Users, Briefcase, Search, Flag, CheckCircle, XCircle, UserX, Eye, Edit, Trash, Star } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { users, services, reviews } from "@/lib/data"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { useRouter } from "next/navigation"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function AdminDashboardPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")

  // In a real app, you would check if the user has admin privileges
  // For this demo, we'll just check if the user is logged in
  if (!user) {
    return (
      <MainLayout>
        <div className="container py-8 flex items-center justify-center">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Access Denied</h2>
              <p className="mb-4">You don't have permission to access the admin dashboard.</p>
              <Button onClick={() => router.push("/")} className="bg-[#055294] hover:bg-[#073761]">
                Back to Home
              </Button>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    )
  }

  // Filter users based on search term
  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Filter services based on search term
  const filteredServices = services.filter(
    (s) =>
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Mock reports data
  const reports = [
    {
      id: "1",
      type: "user",
      reportedId: "3",
      reporterId: "2",
      reason: "Inappropriate behavior",
      status: "pending",
      createdAt: "2025-03-15",
    },
    {
      id: "2",
      type: "service",
      reportedId: "5",
      reporterId: "4",
      reason: "Misleading description",
      status: "resolved",
      createdAt: "2025-03-10",
    },
    {
      id: "3",
      type: "review",
      reportedId: "2",
      reporterId: "6",
      reason: "Fake review",
      status: "pending",
      createdAt: "2025-03-05",
    },
  ]

  return (
    <div className="min-h-screen bg-muted/20 flex">
      <AdminSidebar />

      <div className="flex-1">
        <AdminHeader />

        <main className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-[#073761] mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage users, services, and platform settings</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Users</p>
                    <h3 className="text-3xl font-bold">{users.length}</h3>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-[#2580B7]/10 flex items-center justify-center">
                    <Users className="h-6 w-6 text-[#055294]" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Services</p>
                    <h3 className="text-3xl font-bold">{services.length}</h3>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-[#2580B7]/10 flex items-center justify-center">
                    <Briefcase className="h-6 w-6 text-[#055294]" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Reviews</p>
                    <h3 className="text-3xl font-bold">{reviews.length}</h3>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-[#2580B7]/10 flex items-center justify-center">
                    <Star className="h-6 w-6 text-[#055294]" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Pending Reports</p>
                    <h3 className="text-3xl font-bold">{reports.filter((r) => r.status === "pending").length}</h3>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-[#2580B7]/10 flex items-center justify-center">
                    <Flag className="h-6 w-6 text-[#055294]" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mb-6">
            <div className="relative w-full max-w-md mb-6">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search users, services..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <Tabs defaultValue="users" className="mb-8">
            <TabsList className="grid w-full max-w-md grid-cols-4 mb-6">
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="services">Services</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="users">
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                                <AvatarFallback>
                                  {user.name
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{user.name}</p>
                                <p className="text-xs text-muted-foreground">{user.title}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={user.id === "1" ? "border-[#055294] text-[#055294]" : ""}
                            >
                              {user.id === "1" ? "Admin" : "User"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={user.isOnline ? "bg-green-500" : "bg-muted"}>
                              {user.isOnline ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button variant="ghost" size="icon">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="text-destructive">
                                <UserX className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="services">
              <Card>
                <CardHeader>
                  <CardTitle>Service Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Service</TableHead>
                        <TableHead>Provider</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Rating</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredServices.map((service) => {
                        const serviceProvider = users.find((u) => u.id === service.userId)
                        return (
                          <TableRow key={service.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 rounded bg-muted flex items-center justify-center overflow-hidden">
                                  <img
                                    src={service.image || "/placeholder.svg"}
                                    alt={service.title}
                                    className="h-full w-full object-cover"
                                  />
                                </div>
                                <div>
                                  <p className="font-medium">{service.title}</p>
                                  <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                                    {service.description}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{serviceProvider ? serviceProvider.name : "Unknown"}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{service.category}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
                                <span>{service.rating}</span>
                                <span className="text-xs text-muted-foreground">({service.reviewCount})</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button variant="ghost" size="icon">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="text-destructive">
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reports">
              <Card>
                <CardHeader>
                  <CardTitle>Report Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Reported By</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reports.map((report) => {
                        const reporter = users.find((u) => u.id === report.reporterId)
                        return (
                          <TableRow key={report.id}>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">
                                {report.type}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarImage src={reporter?.avatar || "/placeholder.svg"} alt={reporter?.name} />
                                  <AvatarFallback>
                                    {reporter?.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <span>{reporter?.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>{report.reason}</TableCell>
                            <TableCell>{report.createdAt}</TableCell>
                            <TableCell>
                              <Badge className={report.status === "pending" ? "bg-amber-500" : "bg-green-500"}>
                                {report.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button variant="ghost" size="icon">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="text-green-500">
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="text-destructive">
                                  <XCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Platform Name</label>
                        <Input defaultValue="ConnectPro" />
                      </div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Contact Email</label>
                        <Input defaultValue="support@connectpro.com" />
                      </div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Maximum Services Per User</label>
                        <Input type="number" defaultValue="10" />
                      </div>
                      <Button className="bg-[#055294] hover:bg-[#073761]">Save Settings</Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Email Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">SMTP Server</label>
                        <Input defaultValue="smtp.example.com" />
                      </div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">SMTP Port</label>
                        <Input defaultValue="587" />
                      </div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Email Username</label>
                        <Input defaultValue="notifications@connectpro.com" />
                      </div>
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Email Password</label>
                        <Input type="password" defaultValue="********" />
                      </div>
                      <Button className="bg-[#055294] hover:bg-[#073761]">Test Connection</Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
