"use client"

import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, Users, UserPlus, UserCheck, MessageSquare } from "lucide-react"
import { useConnection } from "@/lib/connection-context"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"

interface UserCardProps {
  id: string
  name: string
  title: string
  rating: number
  connectionCount: number
  avatar: string
}

export function UserCard({ id, name, title, rating, connectionCount, avatar }: UserCardProps) {
  const { getConnectionStatus, sendConnectionRequest } = useConnection()
  const { user } = useAuth()
  const router = useRouter()

  const connectionStatus = getConnectionStatus(id)

  const handleConnect = () => {
    if (connectionStatus === "none") {
      sendConnectionRequest(id)
    } else if (connectionStatus === "accepted") {
      router.push(`/messages?userId=${id}`)
    }
  }

  // Don't show connect button for current user
  const isCurrentUser = user?.id === id

  return (
    <Card className="border-[#2580B7]/20">
      <CardContent className="p-6 text-center">
        <Avatar className="h-20 w-20 mx-auto mb-4">
          <AvatarImage
            src={avatar || "/placeholder.svg"}
            alt={name}
            onError={(e) => {
              // Fallback if avatar fails to load
              ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=80&width=80"
            }}
          />
          <AvatarFallback>
            {name
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>
        <Link href={`/profile/${id}`}>
          <h3 className="font-medium text-lg hover:text-primary transition-colors">{name}</h3>
        </Link>
        <p className="text-sm text-muted-foreground mb-3">{title}</p>
        <div className="flex justify-center items-center gap-4 mb-4">
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-primary text-primary" />
            <span className="text-sm font-medium">{rating}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{connectionCount}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-center">
        {!isCurrentUser &&
          (connectionStatus === "none" ? (
            <Button
              variant="outline"
              size="sm"
              onClick={handleConnect}
              className="gap-2 border-primary text-primary hover:bg-primary hover:text-white"
            >
              <UserPlus className="h-4 w-4" />
              Connect
            </Button>
          ) : connectionStatus === "pending" ? (
            <Button variant="outline" size="sm" disabled className="gap-2 text-muted-foreground">
              <UserCheck className="h-4 w-4" />
              Request Sent
            </Button>
          ) : connectionStatus === "received" ? (
            <Button
              variant="outline"
              size="sm"
              className="gap-2 border-primary text-primary hover:bg-primary hover:text-white"
              onClick={() => router.push("/connections")}
            >
              <UserCheck className="h-4 w-4" />
              Respond to Request
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              onClick={handleConnect}
              className="gap-2 border-primary text-primary hover:bg-primary hover:text-white"
            >
              <MessageSquare className="h-4 w-4" />
              Message
            </Button>
          ))}
      </CardFooter>
    </Card>
  )
}
