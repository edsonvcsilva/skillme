"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ThumbsUp, ThumbsDown, MessageSquare, UserCheck, UserX } from "lucide-react"
import { useConnection } from "@/lib/connection-context"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { motion } from "@/lib/motion"

interface ProminentConnectionButtonsProps {
  userId: string
  userName: string
}

export function ProminentConnectionButtons({ userId, userName }: ProminentConnectionButtonsProps) {
  const { user: currentUser } = useAuth()
  const { getConnectionStatus, sendConnectionRequest, removeConnection, connections } = useConnection()
  const [isAnimating, setIsAnimating] = useState(false)
  const [direction, setDirection] = useState<string | null>(null)
  const router = useRouter()
  const { toast } = useToast()

  if (!currentUser || currentUser.id === userId) return null

  const connectionStatus = getConnectionStatus(userId)

  const handleConnect = () => {
    setIsAnimating(true)
    setDirection("right")

    setTimeout(() => {
      sendConnectionRequest(userId)
      toast({
        title: "Connection Request Sent",
        description: `You sent a connection request to ${userName}`,
      })
      setIsAnimating(false)
      setDirection(null)
    }, 500)
  }

  const handleReject = () => {
    setIsAnimating(true)
    setDirection("left")

    setTimeout(() => {
      // In a real app, you might want to add this user to a "not interested" list
      toast({
        title: "Profile Skipped",
        description: `You've skipped ${userName}'s profile`,
      })
      setIsAnimating(false)
      setDirection(null)
    }, 500)
  }

  const handleMessage = () => {
    router.push(`/messages?userId=${userId}`)
  }

  const handleRemoveConnection = () => {
    // Find the connection to remove
    const connection = connections.find(
      (conn) =>
        (conn.userId === currentUser.id && conn.connectedUserId === userId) ||
        (conn.userId === userId && conn.connectedUserId === currentUser.id),
    )

    if (connection) {
      removeConnection(connection.id)
      toast({
        title: "Connection Removed",
        description: `You are no longer connected with ${userName}`,
      })
    }
  }

  if (connectionStatus === "none") {
    return (
      <motion.div
        className="flex justify-center gap-6 absolute top-1/2 left-0 right-0 transform -translate-y-1/2 z-10"
        animate={isAnimating ? { scale: 1.05 } : { scale: 1 }}
        transition={{ duration: 0.2 }}
      >
        <Button
          size="lg"
          variant="outline"
          className="h-20 w-20 rounded-full border-4 border-destructive text-destructive hover:bg-destructive hover:text-white shadow-lg"
          onClick={handleReject}
        >
          <ThumbsDown className="h-10 w-10" />
        </Button>

        <Button
          size="lg"
          variant="outline"
          className="h-20 w-20 rounded-full border-4 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white shadow-lg"
          onClick={handleConnect}
        >
          <ThumbsUp className="h-10 w-10" />
        </Button>
      </motion.div>
    )
  }

  if (connectionStatus === "pending") {
    return (
      <div className="absolute top-0 left-0 right-0 bg-[#055294]/90 text-white py-2 text-center z-10">
        <div className="flex items-center justify-center gap-2">
          <UserCheck className="h-5 w-5" />
          <span>Connection request sent</span>
        </div>
      </div>
    )
  }

  if (connectionStatus === "received") {
    return (
      <div className="absolute top-0 left-0 right-0 bg-[#055294]/90 text-white py-3 text-center z-10">
        <div className="flex flex-col items-center justify-center gap-2">
          <span className="font-medium">{userName} wants to connect with you</span>
          <div className="flex gap-2 mt-2">
            <Button
              size="sm"
              variant="secondary"
              className="bg-white text-[#055294] hover:bg-white/90"
              onClick={() => router.push("/connections")}
            >
              Respond to Request
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (connectionStatus === "accepted") {
    return (
      <div className="absolute top-0 left-0 right-0 bg-[#055294]/90 text-white py-2 text-center z-10">
        <div className="flex items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            <span>Connected</span>
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              className="bg-white text-[#055294] hover:bg-white/90"
              onClick={handleMessage}
            >
              <MessageSquare className="h-4 w-4 mr-1" />
              Message
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white/20"
              onClick={handleRemoveConnection}
            >
              <UserX className="h-4 w-4 mr-1" />
              Remove
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return null
}
