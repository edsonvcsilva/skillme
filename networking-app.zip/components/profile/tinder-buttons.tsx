"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ThumbsUp, ThumbsDown, MessageSquare, UserCheck, UserX, UserPlus } from "lucide-react"
import { useConnection } from "@/lib/connection-context"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { motion } from "@/lib/motion"

interface TinderButtonsProps {
  userId: string
  userName: string
}

export function TinderButtons({ userId, userName }: TinderButtonsProps) {
  const { user: currentUser } = useAuth()
  const { getConnectionStatus, sendConnectionRequest, removeConnection, connections } = useConnection()
  const [isAnimating, setIsAnimating] = useState(false)
  const [direction, setDirection] = useState<string | null>(null)
  const router = useRouter()
  const { toast } = useToast()

  if (!currentUser || currentUser.id === userId) return null

  const connectionStatus = getConnectionStatus(userId)

  const handleConnect = () => {
    setIsAnimating(true)
    setDirection("right")

    setTimeout(() => {
      sendConnectionRequest(userId)
      toast({
        title: "Connection Request Sent",
        description: `You sent a connection request to ${userName}`,
      })
      setIsAnimating(false)
      setDirection(null)
    }, 500)
  }

  const handleReject = () => {
    setIsAnimating(true)
    setDirection("left")

    setTimeout(() => {
      // In a real app, you might want to add this user to a "not interested" list
      toast({
        title: "Profile Skipped",
        description: `You've skipped ${userName}'s profile`,
      })
      setIsAnimating(false)
      setDirection(null)
    }, 500)
  }

  const handleMessage = () => {
    router.push(`/messages?userId=${userId}`)
  }

  const handleRemoveConnection = () => {
    // Find the connection to remove
    const connection = connections.find(
      (conn) =>
        (conn.userId === currentUser.id && conn.connectedUserId === userId) ||
        (conn.userId === userId && conn.connectedUserId === currentUser.id),
    )

    if (connection) {
      removeConnection(connection.id)
      toast({
        title: "Connection Removed",
        description: `You are no longer connected with ${userName}`,
      })
    }
  }

  return (
    <motion.div
      className="flex justify-center gap-4 mt-6"
      animate={isAnimating ? { scale: 1.05 } : { scale: 1 }}
      transition={{ duration: 0.2 }}
    >
      {connectionStatus === "none" && (
        <>
          <Button
            size="lg"
            variant="outline"
            className="h-14 w-14 rounded-full border-2 border-destructive text-destructive hover:bg-destructive hover:text-white"
            onClick={handleReject}
          >
            <ThumbsDown className="h-6 w-6" />
          </Button>

          <Button
            size="lg"
            variant="outline"
            className="h-14 w-14 rounded-full border-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
            onClick={handleConnect}
          >
            <ThumbsUp className="h-6 w-6" />
          </Button>
        </>
      )}

      {connectionStatus === "pending" && (
        <Button variant="outline" className="gap-2 border-[#055294] text-[#055294]" disabled>
          <UserCheck className="h-5 w-5" />
          Request Sent
        </Button>
      )}

      {connectionStatus === "received" && (
        <div className="flex gap-2">
          <Button className="gap-2 bg-[#055294] hover:bg-[#073761]" onClick={() => router.push("/connections")}>
            <UserPlus className="h-5 w-5" />
            Respond to Request
          </Button>
        </div>
      )}

      {connectionStatus === "accepted" && (
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="gap-2 border-[#055294] text-[#055294] hover:bg-[#055294] hover:text-white"
            onClick={handleMessage}
          >
            <MessageSquare className="h-5 w-5" />
            Message
          </Button>

          <Button
            variant="outline"
            className="gap-2 border-destructive text-destructive hover:bg-destructive hover:text-white"
            onClick={handleRemoveConnection}
          >
            <UserX className="h-5 w-5" />
            Remove Connection
          </Button>
        </div>
      )}
    </motion.div>
  )
}
