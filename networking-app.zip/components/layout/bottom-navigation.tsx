"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Users, MessageSquare, Heart, Wallet } from "lucide-react"
import { useConnection } from "@/lib/connection-context"
import { Badge } from "@/components/ui/badge"
import { useWallet } from "@/lib/wallet-context"

export function BottomNavigation() {
  const pathname = usePathname()
  const { getPendingRequests } = useConnection()
  const { wallet } = useWallet()

  const pendingRequests = getPendingRequests()
  const hasPendingRequests = pendingRequests.length > 0
  const hasWalletBalance = wallet && wallet.balance > 0

  const navigation = [
    { name: "Home", href: "/", icon: Home },
    { name: "Discover", href: "/discover", icon: Heart },
    { name: "Messages", href: "/messages", icon: MessageSquare },
    { name: "Connections", href: "/connections", icon: Users, badge: hasPendingRequests },
    { name: "Wallet", href: "/wallet", icon: Wallet, badge: hasWalletBalance },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t z-50 md:hidden">
      <div className="flex justify-around items-center h-16">
        {navigation.map((item) => {
          const isActive = pathname === item.href

          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex flex-col items-center justify-center w-full h-full ${
                isActive ? "text-[#055294]" : "text-muted-foreground"
              }`}
            >
              <div className="relative">
                <item.icon className="h-6 w-6" />
                {item.badge && (
                  <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center bg-[#055294]">
                    {item.name === "Connections" ? pendingRequests.length : "$"}
                  </Badge>
                )}
              </div>
              <span className="text-xs mt-1">{item.name}</span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
