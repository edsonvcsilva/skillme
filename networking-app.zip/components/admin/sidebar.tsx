"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Users, Briefcase, MessageSquare, Flag, Settings, BarChart3, LogOut } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"

export function AdminSidebar() {
  const pathname = usePathname()
  const { logout } = useAuth()

  const navigation = [
    { name: "Dashboard", href: "/admin", icon: LayoutDashboard },
    { name: "Users", href: "/admin/users", icon: Users },
    { name: "Services", href: "/admin/services", icon: Briefcase },
    { name: "Messages", href: "/admin/messages", icon: MessageSquare },
    { name: "Reports", href: "/admin/reports", icon: Flag },
    { name: "Analytics", href: "/admin/analytics", icon: BarChart3 },
    { name: "Settings", href: "/admin/settings", icon: Settings },
  ]

  return (
    <div className="w-64 bg-[#073761] text-white min-h-screen hidden md:block">
      <div className="p-6">
        <Link href="/admin" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center">
            <span className="text-[#073761] font-bold">CP</span>
          </div>
          <span className="text-xl font-bold">ConnectPro</span>
        </Link>
      </div>

      <div className="px-3 py-2">
        <p className="px-3 text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Management</p>
        <nav className="space-y-1">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive ? "bg-[#055294] text-white" : "text-white/70 hover:bg-[#055294]/50 hover:text-white"
                }`}
              >
                <item.icon className="h-5 w-5" />
                {item.name}
              </Link>
            )
          })}
        </nav>
      </div>

      <div className="absolute bottom-0 w-64 p-4">
        <Link href="/">
          <Button variant="ghost" className="w-full justify-start text-white hover:bg-[#055294]/50">
            <LayoutDashboard className="h-5 w-5 mr-2" />
            Back to Site
          </Button>
        </Link>
        <Button variant="ghost" className="w-full justify-start text-white hover:bg-[#055294]/50 mt-2" onClick={logout}>
          <LogOut className="h-5 w-5 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  )
}
