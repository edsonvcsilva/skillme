import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface ServiceCardProps {
  id: string
  title: string
  description: string
  rating: number
  reviewCount: number
  category: string
  userName: string
  userAvatar: string
  image: string
}

export function ServiceCard({
  id,
  title,
  description,
  rating,
  reviewCount,
  category,
  userName,
  userAvatar,
  image,
}: ServiceCardProps) {
  return (
    <Card className="overflow-hidden border-[#2580B7]/20 hover:shadow-md transition-shadow">
      <CardHeader className="p-0">
        <Link href={`/services/${id}`}>
          <div className="h-40 bg-muted flex items-center justify-center overflow-hidden">
            <img
              src={image || "/placeholder.svg"}
              alt={title}
              className="w-full h-full object-cover"
              onError={(e) => {
                // Fallback if image fails to load
                ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=160&width=320"
              }}
            />
          </div>
        </Link>
      </CardHeader>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <Badge variant="outline" className="mb-2 border-[#2580B7]/30">
            {category}
          </Badge>
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-[#055294] text-[#055294]" />
            <span className="text-sm font-medium">{rating}</span>
            <span className="text-xs text-muted-foreground">({reviewCount})</span>
          </div>
        </div>
        <Link href={`/services/${id}`}>
          <CardTitle className="text-lg mb-2 hover:text-[#055294] transition-colors">{title}</CardTitle>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex items-center gap-2">
        <Link href={`/profile/${id.split("-")[0]}`} className="flex items-center gap-2 hover:text-[#055294]">
          <Avatar className="h-8 w-8">
            <AvatarImage
              src={userAvatar || "/placeholder.svg"}
              alt={userName}
              onError={(e) => {
                // Fallback if avatar fails to load
                ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=32&width=32"
              }}
            />
            <AvatarFallback>
              {userName
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium">{userName}</span>
        </Link>
      </CardFooter>
    </Card>
  )
}
