import type React from "react"
// This is a simplified version of framer-motion for the example
// In a real app, you would install framer-motion

export const motion = {
  div: ({ children, className, initial, animate, exit, transition, key }: any) => {
    return (
      <div key={key} className={className}>
        {children}
      </div>
    )
  },
}

export const AnimatePresence = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>
}
