"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "@/lib/auth-context"
import type { Transaction, Wallet } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface WalletContextType {
  wallet: Wallet | null
  addFunds: (amount: number) => Promise<boolean>
  withdrawFunds: (amount: number) => Promise<boolean>
  makePayment: (amount: number, description: string) => Promise<boolean>
  earnPoints: (points: number, description: string) => Promise<boolean>
  usePoints: (points: number, description: string) => Promise<boolean>
  getRecentTransactions: (limit?: number) => Transaction[]
  isLoading: boolean
}

const WalletContext = createContext<WalletContextType | undefined>(undefined)

export function WalletProvider({ children }: { children: ReactNode }) {
  const { user, updateUserWallet } = useAuth()
  const { toast } = useToast()
  const [wallet, setWallet] = useState<Wallet | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Replace the two useEffect hooks with a single, more carefully controlled one
  useEffect(() => {
    if (user) {
      setIsLoading(true)
      // If user has a wallet, use it
      if (user.wallet) {
        setWallet(user.wallet)
      } else {
        // Check if there's a wallet in localStorage
        const storedWallet = localStorage.getItem(`wallet_${user.id}`)
        if (storedWallet) {
          const parsedWallet = JSON.parse(storedWallet)
          setWallet(parsedWallet)
          // Only update the user wallet if it doesn't exist yet
          updateUserWallet(parsedWallet)
        } else {
          // Initialize a new wallet
          const newWallet: Wallet = {
            balance: 0,
            points: 0,
            transactions: [],
          }
          setWallet(newWallet)
          localStorage.setItem(`wallet_${user.id}`, JSON.stringify(newWallet))
          updateUserWallet(newWallet)
        }
      }
      setIsLoading(false)
    } else {
      setWallet(null)
      setIsLoading(false)
    }
  }, [user, updateUserWallet])

  // Add a separate effect to save wallet changes to localStorage, but NOT update the user
  useEffect(() => {
    if (user && wallet) {
      localStorage.setItem(`wallet_${user.id}`, JSON.stringify(wallet))
    }
  }, [user, wallet])

  // Modify the addTransaction function to update the user wallet after state changes
  const addTransaction = (transaction: Omit<Transaction, "id" | "date" | "status">): Transaction => {
    const newTransaction: Transaction = {
      id: `txn_${Date.now()}`,
      date: new Date().toISOString(),
      status: "completed",
      ...transaction,
    }

    // Update wallet state
    const updatedWallet = wallet
      ? {
          ...wallet,
          transactions: [newTransaction, ...wallet.transactions],
        }
      : null

    setWallet(updatedWallet)

    return newTransaction
  }

  const addFunds = async (amount: number): Promise<boolean> => {
    if (!wallet || amount <= 0) return false

    try {
      // In a real app, this would be an API call to a payment processor
      // Simulate a delay for the payment processing
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setWallet((prev) => {
        if (!prev) return null
        return {
          ...prev,
          balance: prev.balance + amount,
        }
      })

      addTransaction({
        type: "deposit",
        amount,
        description: `Added ${amount.toFixed(2)} to wallet`,
      })

      toast({
        title: "Funds Added",
        description: `${amount.toFixed(2)} has been added to your wallet.`,
      })

      return true
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add funds. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  const withdrawFunds = async (amount: number): Promise<boolean> => {
    if (!wallet || amount <= 0 || wallet.balance < amount) return false

    try {
      // Simulate a delay for the withdrawal processing
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setWallet((prev) => {
        if (!prev) return null
        return {
          ...prev,
          balance: prev.balance - amount,
        }
      })

      addTransaction({
        type: "withdrawal",
        amount: -amount,
        description: `Withdrew ${amount.toFixed(2)} from wallet`,
      })

      toast({
        title: "Funds Withdrawn",
        description: `${amount.toFixed(2)} has been withdrawn from your wallet.`,
      })

      return true
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to withdraw funds. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  const makePayment = async (amount: number, description: string): Promise<boolean> => {
    if (!wallet || amount <= 0 || wallet.balance < amount) return false

    try {
      // Simulate a delay for the payment processing
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setWallet((prev) => {
        if (!prev) return null
        return {
          ...prev,
          balance: prev.balance - amount,
        }
      })

      addTransaction({
        type: "payment",
        amount: -amount,
        description,
      })

      // Award points for making a payment (1 point per $10 spent)
      const pointsEarned = Math.floor(amount / 10)
      if (pointsEarned > 0) {
        earnPoints(pointsEarned, `Points earned for ${amount.toFixed(2)} payment`)
      }

      toast({
        title: "Payment Successful",
        description: `${amount.toFixed(2)} has been paid for ${description}.`,
      })

      return true
    } catch (error) {
      toast({
        title: "Error",
        description: "Payment failed. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  const earnPoints = async (points: number, description: string): Promise<boolean> => {
    if (!wallet || points <= 0) return false

    try {
      setWallet((prev) => {
        if (!prev) return null
        return {
          ...prev,
          points: prev.points + points,
        }
      })

      addTransaction({
        type: "points_earned",
        amount: points,
        description,
      })

      return true
    } catch (error) {
      return false
    }
  }

  const usePoints = async (points: number, description: string): Promise<boolean> => {
    if (!wallet || points <= 0 || wallet.points < points) return false

    try {
      setWallet((prev) => {
        if (!prev) return null
        return {
          ...prev,
          points: prev.points - points,
        }
      })

      addTransaction({
        type: "points_used",
        amount: -points,
        description,
      })

      toast({
        title: "Points Used",
        description: `${points} points have been used for ${description}.`,
      })

      return true
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to use points. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  const getRecentTransactions = (limit = 10): Transaction[] => {
    if (!wallet) return []
    return wallet.transactions.slice(0, limit)
  }

  return (
    <WalletContext.Provider
      value={{
        wallet,
        addFunds,
        withdrawFunds,
        makePayment,
        earnPoints,
        usePoints,
        getRecentTransactions,
        isLoading,
      }}
    >
      {children}
    </WalletContext.Provider>
  )
}

export function useWallet() {
  const context = useContext(WalletContext)
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider")
  }
  return context
}
