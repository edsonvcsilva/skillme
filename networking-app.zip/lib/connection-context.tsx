"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "@/lib/auth-context"
import type { Connection } from "@/lib/types"
import { connections as initialConnections } from "@/lib/data"

interface ConnectionContextType {
  connections: Connection[]
  sendConnectionRequest: (userId: string) => void
  acceptConnectionRequest: (connectionId: string) => void
  rejectConnectionRequest: (connectionId: string) => void
  removeConnection: (connectionId: string) => void
  getConnectionStatus: (userId: string) => "none" | "pending" | "accepted" | "received"
  getPendingRequests: () => Connection[]
  getConnectionById: (connectionId: string) => Connection | undefined
}

const ConnectionContext = createContext<ConnectionContextType | undefined>(undefined)

export function ConnectionProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [connections, setConnections] = useState<Connection[]>([])

  useEffect(() => {
    // Load connections from localStorage or use initial data
    const storedConnections = localStorage.getItem("connections")
    if (storedConnections) {
      setConnections(JSON.parse(storedConnections))
    } else {
      setConnections(initialConnections)
    }
  }, [])

  // Save connections to localStorage whenever they change
  useEffect(() => {
    if (connections.length > 0) {
      localStorage.setItem("connections", JSON.stringify(connections))
    }
  }, [connections])

  const sendConnectionRequest = (userId: string) => {
    if (!user) return

    // Check if a connection already exists
    const existingConnection = connections.find(
      (conn) =>
        (conn.userId === user.id && conn.connectedUserId === userId) ||
        (conn.userId === userId && conn.connectedUserId === user.id),
    )

    if (existingConnection) return

    // Create a new connection request
    const newConnection: Connection = {
      id: `conn_${Date.now()}`,
      userId: user.id,
      connectedUserId: userId,
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    setConnections((prev) => [...prev, newConnection])
  }

  const acceptConnectionRequest = (connectionId: string) => {
    setConnections((prev) => prev.map((conn) => (conn.id === connectionId ? { ...conn, status: "accepted" } : conn)))
  }

  const rejectConnectionRequest = (connectionId: string) => {
    setConnections((prev) => prev.map((conn) => (conn.id === connectionId ? { ...conn, status: "rejected" } : conn)))
  }

  const removeConnection = (connectionId: string) => {
    setConnections((prev) => prev.filter((conn) => conn.id !== connectionId))
  }

  const getConnectionStatus = (userId: string): "none" | "pending" | "accepted" | "received" => {
    if (!user) return "none"

    const connection = connections.find(
      (conn) =>
        (conn.userId === user.id && conn.connectedUserId === userId) ||
        (conn.userId === userId && conn.connectedUserId === user.id),
    )

    if (!connection) return "none"

    if (connection.status === "accepted") return "accepted"

    if (connection.userId === user.id) return "pending"

    return "received"
  }

  const getPendingRequests = (): Connection[] => {
    if (!user) return []

    return connections.filter((conn) => conn.connectedUserId === user.id && conn.status === "pending")
  }

  const getConnectionById = (connectionId: string): Connection | undefined => {
    return connections.find((conn) => conn.id === connectionId)
  }

  return (
    <ConnectionContext.Provider
      value={{
        connections,
        sendConnectionRequest,
        acceptConnectionRequest,
        rejectConnectionRequest,
        removeConnection,
        getConnectionStatus,
        getPendingRequests,
        getConnectionById,
      }}
    >
      {children}
    </ConnectionContext.Provider>
  )
}

export function useConnection() {
  const context = useContext(ConnectionContext)
  if (context === undefined) {
    throw new Error("useConnection must be used within a ConnectionProvider")
  }
  return context
}
