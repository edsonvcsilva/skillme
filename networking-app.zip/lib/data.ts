import type { User, Service, Message, Connection, Review, Wallet, Transaction } from "@/lib/types"

// Sample wallet transactions
const sampleTransactions: Transaction[] = [
  {
    id: "txn_1",
    type: "deposit",
    amount: 100,
    description: "Initial deposit",
    date: "2025-04-10T14:30:00",
    status: "completed",
  },
  {
    id: "txn_2",
    type: "payment",
    amount: -25,
    description: "Payment for Web Development service",
    date: "2025-04-11T09:15:00",
    status: "completed",
  },
  {
    id: "txn_3",
    type: "points_earned",
    amount: 50,
    description: "Welcome bonus points",
    date: "2025-04-10T14:35:00",
    status: "completed",
  },
]

// Sample wallet
const sampleWallet: Wallet = {
  balance: 75,
  points: 50,
  transactions: sampleTransactions,
}

// Fake users data
export const users: User[] = [
  {
    id: "1",
    name: "John Doe",
    username: "johndoe",
    email: "john@example.com",
    password: "password123", // In a real app, this would be hashed
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover1.jpg",
    title: "Full-stack Developer",
    bio: "Experienced full-stack developer specializing in React, Next.js, and Node.js. Passionate about creating clean, efficient, and user-friendly web applications.",
    location: "São Paulo, Brazil",
    skills: ["JavaScript", "React", "Next.js", "Node.js", "TypeScript", "UI/UX"],
    rating: 4.9,
    reviewCount: 32,
    connectionCount: 143,
    memberSince: "2021-03-15",
    isOnline: true,
    wallet: sampleWallet,
  },
  {
    id: "2",
    name: "Alex Johnson",
    username: "alexj",
    email: "alex@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover2.jpg",
    title: "UX/UI Designer",
    bio: "Creative UX/UI designer with a passion for creating beautiful and functional user interfaces. I specialize in web and mobile app design.",
    location: "Rio de Janeiro, Brazil",
    skills: ["UI/UX", "Figma", "Adobe XD", "Sketch", "Prototyping"],
    rating: 4.8,
    reviewCount: 24,
    connectionCount: 156,
    memberSince: "2020-05-22",
    isOnline: true,
  },
  {
    id: "3",
    name: "Maria Garcia",
    username: "mariag",
    email: "maria@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover3.jpg",
    title: "Graphic Designer",
    bio: "Passionate graphic designer with over 5 years of experience. I specialize in branding, logo design, and marketing materials.",
    location: "Belo Horizonte, Brazil",
    skills: ["Graphic Design", "Adobe Illustrator", "Adobe Photoshop", "Branding", "Typography"],
    rating: 4.9,
    reviewCount: 36,
    connectionCount: 203,
    memberSince: "2019-11-10",
    isOnline: false,
  },
  {
    id: "4",
    name: "David Kim",
    username: "davidk",
    email: "david@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover4.jpg",
    title: "Digital Marketer",
    bio: "Results-driven digital marketer specializing in SEO, social media marketing, and content strategy. I help businesses grow their online presence.",
    location: "Curitiba, Brazil",
    skills: ["SEO", "Social Media", "Content Marketing", "Google Analytics", "PPC"],
    rating: 4.7,
    reviewCount: 18,
    connectionCount: 124,
    memberSince: "2020-08-05",
    isOnline: true,
  },
  {
    id: "5",
    name: "Sarah Williams",
    username: "sarahw",
    email: "sarah@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover5.jpg",
    title: "Content Writer",
    bio: "Professional content writer with a knack for creating engaging and SEO-friendly content. I specialize in blog posts, website copy, and social media content.",
    location: "Brasília, Brazil",
    skills: ["Content Writing", "Copywriting", "SEO Writing", "Blogging", "Editing"],
    rating: 4.9,
    reviewCount: 29,
    connectionCount: 178,
    memberSince: "2021-01-18",
    isOnline: false,
  },
  {
    id: "6",
    name: "Michael Brown",
    username: "michaelb",
    email: "michael@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover6.jpg",
    title: "Mobile App Developer",
    bio: "Experienced mobile app developer specializing in iOS and Android development. I create beautiful and functional mobile applications.",
    location: "Porto Alegre, Brazil",
    skills: ["iOS", "Android", "React Native", "Flutter", "Swift", "Kotlin"],
    rating: 4.8,
    reviewCount: 22,
    connectionCount: 135,
    memberSince: "2020-04-12",
    isOnline: true,
  },
  {
    id: "7",
    name: "Emily Chen",
    username: "emilyc",
    email: "emily@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover7.jpg",
    title: "UI/UX Designer",
    bio: "Passionate UI/UX designer focused on creating intuitive and engaging user experiences. I specialize in web and mobile app design.",
    location: "Salvador, Brazil",
    skills: ["UI Design", "UX Design", "Wireframing", "Prototyping", "User Research"],
    rating: 4.9,
    reviewCount: 29,
    connectionCount: 167,
    memberSince: "2019-09-30",
    isOnline: false,
  },
  {
    id: "8",
    name: "Robert Taylor",
    username: "robertt",
    email: "robert@example.com",
    password: "password123",
    avatar: "/images/default-avatar.png",
    coverImage: "/images/covers/cover8.jpg",
    title: "Business Consultant",
    bio: "Strategic business consultant with expertise in helping startups and established companies grow. I provide actionable insights and strategies.",
    location: "Recife, Brazil",
    skills: ["Business Strategy", "Market Analysis", "Financial Planning", "Growth Hacking", "Mentoring"],
    rating: 4.7,
    reviewCount: 14,
    connectionCount: 112,
    memberSince: "2020-07-15",
    isOnline: true,
  },
]

// Fake services data
export const services: Service[] = [
  {
    id: "1",
    userId: "1",
    title: "Web Development",
    description:
      "Full-stack web development services including React, Next.js, and Node.js. I can build responsive, scalable web applications tailored to your needs.",
    category: "Development",
    rating: 4.9,
    reviewCount: 24,
    image: "/images/services/webdev.jpg",
    createdAt: "2023-05-15",
  },
  {
    id: "2",
    userId: "1",
    title: "UI/UX Design",
    description:
      "User interface and experience design for web and mobile applications. I focus on creating intuitive, user-friendly designs that enhance user engagement.",
    category: "Design",
    rating: 4.8,
    reviewCount: 18,
    image: "/images/services/uiux.jpg",
    createdAt: "2023-06-22",
  },
  {
    id: "3",
    userId: "2",
    title: "UX/UI Design",
    description:
      "Professional UI/UX design services for web and mobile applications. I create beautiful, intuitive interfaces that users love.",
    category: "Design",
    rating: 4.8,
    reviewCount: 22,
    image: "/images/services/uxdesign.jpg",
    createdAt: "2023-04-10",
  },
  {
    id: "4",
    userId: "3",
    title: "Graphic Design",
    description:
      "Professional graphic design for logos, branding, and marketing materials. I help businesses establish a strong visual identity.",
    category: "Design",
    rating: 4.9,
    reviewCount: 36,
    image: "/images/services/graphicdesign.jpg",
    createdAt: "2023-03-05",
  },
  {
    id: "5",
    userId: "4",
    title: "Digital Marketing",
    description:
      "SEO, social media marketing, and content strategy services. I help businesses improve their online visibility and reach their target audience.",
    category: "Marketing",
    rating: 4.7,
    reviewCount: 18,
    image: "/images/services/digitalmarketing.jpg",
    createdAt: "2023-02-18",
  },
  {
    id: "6",
    userId: "5",
    title: "Content Writing",
    description:
      "High-quality content writing for blogs, websites, and social media. I create engaging, SEO-friendly content that resonates with your audience.",
    category: "Writing",
    rating: 4.6,
    reviewCount: 15,
    image: "/images/services/contentwriting.jpg",
    createdAt: "2023-01-25",
  },
  {
    id: "7",
    userId: "6",
    title: "Mobile App Development",
    description:
      "Native and cross-platform mobile app development for iOS and Android. I build high-performance, feature-rich mobile applications.",
    category: "Development",
    rating: 4.8,
    reviewCount: 22,
    image: "/images/services/mobiledev.jpg",
    createdAt: "2023-04-30",
  },
  {
    id: "8",
    userId: "7",
    title: "UI/UX Design",
    description:
      "User interface and experience design for web and mobile applications. I create designs that are both beautiful and functional.",
    category: "Design",
    rating: 4.9,
    reviewCount: 29,
    image: "/images/services/uidesign.jpg",
    createdAt: "2023-03-12",
  },
  {
    id: "9",
    userId: "8",
    title: "Business Consulting",
    description:
      "Strategic business consulting for startups and established companies. I provide actionable insights to help your business grow.",
    category: "Business",
    rating: 4.7,
    reviewCount: 14,
    image: "/images/services/consulting.jpg",
    createdAt: "2023-05-05",
  },
]

// Fake reviews data
export const reviews: Review[] = [
  {
    id: "1",
    serviceId: "1",
    userId: "2",
    rating: 5,
    comment:
      "John did an excellent job on our website. He was professional, responsive, and delivered the project on time. The quality of his work exceeded our expectations.",
    createdAt: "2023-06-15",
  },
  {
    id: "2",
    serviceId: "1",
    userId: "3",
    rating: 5,
    comment:
      "Working with John was a great experience. He understood our requirements perfectly and delivered a website that perfectly matched our vision.",
    createdAt: "2023-05-22",
  },
  {
    id: "3",
    serviceId: "1",
    userId: "4",
    rating: 4,
    comment:
      "John is a skilled developer who created a fantastic website for our business. The only reason for 4 stars is that we had a slight delay in the project timeline.",
    createdAt: "2023-04-10",
  },
  {
    id: "4",
    serviceId: "2",
    userId: "5",
    rating: 5,
    comment:
      "John's UI/UX design skills are top-notch. He created an intuitive and beautiful interface for our app that our users love.",
    createdAt: "2023-07-05",
  },
  {
    id: "5",
    serviceId: "2",
    userId: "6",
    rating: 5,
    comment:
      "I'm extremely satisfied with John's design work. He has a great eye for detail and created a design that perfectly aligned with our brand.",
    createdAt: "2023-06-18",
  },
]

// Fake connections data
export const connections: Connection[] = [
  {
    id: "1",
    userId: "1",
    connectedUserId: "2",
    status: "accepted",
    createdAt: "2023-01-15",
  },
  {
    id: "2",
    userId: "1",
    connectedUserId: "3",
    status: "accepted",
    createdAt: "2023-02-10",
  },
  {
    id: "3",
    userId: "1",
    connectedUserId: "4",
    status: "accepted",
    createdAt: "2023-03-05",
  },
  {
    id: "4",
    userId: "1",
    connectedUserId: "5",
    status: "pending",
    createdAt: "2023-04-20",
  },
  {
    id: "5",
    userId: "2",
    connectedUserId: "3",
    status: "accepted",
    createdAt: "2023-01-25",
  },
]

// Fake messages data
export const messages: Message[] = [
  {
    id: "1",
    senderId: "2",
    receiverId: "1",
    content: "Hey, how's the project going?",
    createdAt: "2023-07-15T10:30:00",
    read: false,
  },
  {
    id: "2",
    senderId: "1",
    receiverId: "2",
    content: "It's going well! I've completed the frontend and now working on the API integration.",
    createdAt: "2023-07-15T10:32:00",
    read: true,
  },
  {
    id: "3",
    senderId: "2",
    receiverId: "1",
    content: "That's great! Do you need any help with the API?",
    createdAt: "2023-07-15T10:33:00",
    read: false,
  },
  {
    id: "4",
    senderId: "1",
    receiverId: "2",
    content: "I think I'm good for now, but I might need your help with the authentication part later.",
    createdAt: "2023-07-15T10:35:00",
    read: true,
  },
  {
    id: "5",
    senderId: "2",
    receiverId: "1",
    content: "Sure, just let me know when you're ready. I've implemented similar authentication systems before.",
    createdAt: "2023-07-15T10:36:00",
    read: false,
  },
  {
    id: "6",
    senderId: "3",
    receiverId: "1",
    content: "Thanks for your help yesterday!",
    createdAt: "2023-07-14T15:20:00",
    read: true,
  },
  {
    id: "7",
    senderId: "4",
    receiverId: "1",
    content: "Can we schedule a call tomorrow?",
    createdAt: "2023-07-14T13:45:00",
    read: true,
  },
  {
    id: "8",
    senderId: "5",
    receiverId: "1",
    content: "The design looks great!",
    createdAt: "2023-07-13T09:15:00",
    read: true,
  },
]

// Helper function to get user by ID
export function getUserById(id: string): User | undefined {
  return users.find((user) => user.id === id)
}

// Helper function to get service by ID
export function getServiceById(id: string): Service | undefined {
  return services.find((service) => service.id === id)
}

// Helper function to get services by user ID
export function getServicesByUserId(userId: string): Service[] {
  return services.filter((service) => service.userId === userId)
}

// Helper function to get reviews by service ID
export function getReviewsByServiceId(serviceId: string): Review[] {
  return reviews.filter((review) => review.serviceId === serviceId)
}

// Helper function to get connections by user ID
export function getConnectionsByUserId(userId: string): Connection[] {
  return connections.filter((connection) => connection.userId === userId || connection.connectedUserId === userId)
}

// Helper function to get connected users by user ID
export function getConnectedUsersByUserId(userId: string): User[] {
  const userConnections = connections.filter(
    (connection) =>
      (connection.userId === userId || connection.connectedUserId === userId) && connection.status === "accepted",
  )

  return userConnections.map((connection) => {
    const connectedUserId = connection.userId === userId ? connection.connectedUserId : connection.userId
    return getUserById(connectedUserId)!
  })
}

// Helper function to get messages between two users
export function getMessagesBetweenUsers(userId1: string, userId2: string): Message[] {
  return messages
    .filter(
      (message) =>
        (message.senderId === userId1 && message.receiverId === userId2) ||
        (message.senderId === userId2 && message.receiverId === userId1),
    )
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
}

// Helper function to get unread message count for a user
export function getUnreadMessageCount(userId: string): number {
  return messages.filter((message) => message.receiverId === userId && !message.read).length
}

// Helper function to get unread message count from a specific sender
export function getUnreadMessageCountFromSender(receiverId: string, senderId: string): number {
  return messages.filter(
    (message) => message.receiverId === receiverId && message.senderId === senderId && !message.read,
  ).length
}
