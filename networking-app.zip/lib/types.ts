export interface User {
  id: string
  name: string
  username: string
  email: string
  password: string
  avatar: string
  coverImage?: string
  title: string
  bio: string
  location: string
  skills: string[]
  rating: number
  reviewCount: number
  connectionCount: number
  memberSince: string
  isOnline: boolean
  wallet?: Wallet
}

export interface Wallet {
  balance: number
  points: number
  transactions: Transaction[]
}

export interface Transaction {
  id: string
  type: "deposit" | "withdrawal" | "payment" | "refund" | "points_earned" | "points_used"
  amount: number
  description: string
  date: string
  status: "completed" | "pending" | "failed"
}

export interface Service {
  id: string
  userId: string
  title: string
  description: string
  category: string
  rating: number
  reviewCount: number
  image: string
  createdAt: string
}

export interface Review {
  id: string
  serviceId: string
  userId: string
  rating: number
  comment: string
  createdAt: string
}

export interface Connection {
  id: string
  userId: string
  connectedUserId: string
  status: "pending" | "accepted" | "rejected"
  createdAt: string
}

export interface Message {
  id: string
  senderId: string
  receiverId: string
  content: string
  createdAt: string
  read: boolean
}
